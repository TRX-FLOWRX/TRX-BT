"""
TROXZY OCR VERIFICATION ENGINE
Payment Proof Scanner
Badan_Intelijen_Negara Protocol
"""

import re
from typing import Dict, Optional
from PIL import Image
import pytesseract
from io import BytesIO

def extract_text_from_image(image_bytes: bytes) -> str:
    try:
        image = Image.open(BytesIO(image_bytes))
        image = image.convert("L")
        text = pytesseract.image_to_string(image, lang="ind+eng")
        return text
    except Exception as e:
        return "OCR_ERROR: " + str(e)

def verify_payment_proof(text: str, expected_name: str, expected_amount: int) -> Dict:
    result = {
        "valid": False,
        "confidence": 0.0,
        "detected_name": None,
        "detected_amount": None,
        "detected_time": None,
        "errors": []
    }
    text_upper = text.upper()
    name_found = False
    if expected_name.upper() in text_upper:
        result["detected_name"] = expected_name
        name_found = True
    if not name_found:
        result["errors"].append("Sender name not found or mismatch")
    amount_found = False
    if str(expected_amount) in text:
        result["detected_amount"] = str(expected_amount)
        amount_found = True
    if not amount_found:
        result["errors"].append("Amount not found or mismatch")
    time_patterns = [
        r"(\d{2}[/-]\d{2}[/-]\d{4}\s+\d{2}:\d{2})",
        r"(\d{2}:\d{2}\s+\d{2}[/-]\d{2}[/-]\d{4})",
        r"(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2})"
    ]
    for pattern in time_patterns:
        match = re.search(pattern, text)
        if match:
            result["detected_time"] = match.group(1)
            break
    score = 0
    if name_found: score += 40
    if amount_found: score += 40
    if result["detected_time"]: score += 20
    result["confidence"] = score / 100
    result["valid"] = score >= 70
    return result

def format_verification_result(result: Dict) -> str:
    status = "✅ VALID" if result["valid"] else "⚠️ NEEDS REVIEW"
    conf = int(result["confidence"] * 10)
    confidence_bar = "█" * conf + "░" * (10 - conf)
    dn = result.get("detected_name", "N/A")
    da = result.get("detected_amount", "N/A")
    dt = result.get("detected_time", "N/A")
    text = "🔍 **OCR VERIFICATION RESULT**\n\n`Status:` " + status + "\n`Confidence:` `[" + confidence_bar + "]` " + str(int(result["confidence"] * 100)) + "%\n\n`Detected Name:` " + dn + "\n`Detected Amount:` " + da + "\n`Detected Time:` " + dt
    if result["errors"]:
        text += "\n\n`⚠️ Issues:`\n"
        for error in result["errors"]:
            text += "• " + error + "\n"
    return text
