"""
🛡️ TROXZY RATE LIMITER
Middleware pembatas laju permintaan per-user
Badan_Intelijen_Negara Protocol

Dipasang sebagai handler global di group=-1 (paling awal dieksekusi, sebelum
command/callback handler manapun). Kalau user melanggar limit, handler ini
menghentikan propagasi update ke handler lain lewat ApplicationHandlerStop,
sehingga command/callback aslinya tidak pernah tereksekusi.

PENTING — cakupan rate limit dibatasi HANYA untuk command (/xxx) dan callback
query (klik tombol inline). Pesan teks bebas (mis. user mengetik nama domain
saat diminta oleh tools_conv, atau nama lengkap saat submit_proof_handler)
TIDAK dikenai rate limit, karena itu adalah kelanjutan alur ConversationHandler
yang sudah user mulai sendiri secara sah — membatasinya hanya akan merusak
alur wizard yang sudah ada (mis. user bisa "diblokir" cooldown padahal baru
saja mengisi kolom yang diminta bot).

Dua lapis pembatasan, sesuai config.py:
1. COOLDOWN (RATE_LIMIT_SECONDS) — jeda minimum antar command/klik tombol baru,
   mencegah spam beruntun (mis. spam klik command dengan sangat cepat).
2. QUOTA PER MENIT (MAX_REQUESTS_PER_MINUTE) — membatasi jumlah operasi berat
   (recon tools + AI chat) dalam jendela 60 detik, mencegah penyalahgunaan tool
   pihak ketiga (WHOIS/DNS/port-scan) dan pemborosan kuota AI API.
"""

import logging
from telegram import Update
from telegram.ext import ContextTypes, ApplicationHandlerStop

import config
from utils.database import db

logger = logging.getLogger(__name__)

# Command yang selalu dibebaskan dari rate limit karena ringan atau justru
# dibutuhkan kapan saja (mis. /cancel harus selalu bisa dipakai untuk keluar
# dari sebuah ConversationHandler yang sedang berjalan).
EXEMPT_COMMANDS = {"/cancel", "/start", "/help"}

# Prefix callback_data yang tergolong "berat" dan ikut dihitung ke kuota per menit.
# Navigasi menu biasa (menu_*, back_button, dsb.) TIDAK dihitung supaya orang tetap
# bisa bebas berpindah menu meski kuota tool-nya sedang penuh.
HEAVY_CALLBACK_PREFIXES = ("tool_", "bb_recon_")

# Command yang tergolong berat (memicu pemanggilan API/tool eksternal).
HEAVY_COMMANDS = {"/ai", "/tools", "/bugbounty"}


def _is_exempt(user_id: int) -> bool:
    """Admin tidak dibatasi rate limit, supaya broadcast & operasi admin tidak tertahan."""
    return user_id in config.ADMIN_IDS


def _extract_command(update: Update) -> str:
    if update.message and update.message.text:
        return update.message.text.split()[0].split("@")[0].lower()
    return ""


def _is_rate_limitable(update: Update) -> bool:
    """
    Hanya command (teks diawali '/') dan callback query (klik tombol) yang
    dikenai rate limit. Pesan teks bebas (balasan dalam ConversationHandler
    aktif seperti input domain/nama pembayaran) selalu dilewatkan.
    """
    if update.callback_query is not None:
        return True
    if update.message and update.message.text and update.message.text.startswith("/"):
        return True
    return False


async def rate_limit_middleware(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Handler global — didaftarkan di group=-1 sehingga selalu jalan lebih dulu.
    Tidak melakukan apa pun kalau user masih dalam batas wajar, atau kalau update
    ini bukan command/callback (lihat _is_rate_limitable); melempar
    ApplicationHandlerStop kalau harus diblok (setelah mengirim pesan peringatan).
    """
    user = update.effective_user
    if user is None:
        return

    if _is_exempt(user.id):
        return

    if not _is_rate_limitable(update):
        return

    command = _extract_command(update)
    if command in EXEMPT_COMMANDS:
        return

    # ── Lapis 1: cooldown antar-command/tombol ──
    remaining = db.check_cooldown(user.id, config.RATE_LIMIT_SECONDS)
    if remaining is not None:
        warning = (
            "🛑 **RATE LIMIT**\n"
            f"`Cooldown aktif:` tunggu {remaining:.1f} detik lagi.\n"
            f"`Batas:` {config.RATE_LIMIT_SECONDS} detik antar perintah."
        )
        await _notify(update, warning)
        raise ApplicationHandlerStop

    # ── Lapis 2: kuota per menit, hanya untuk operasi berat ──
    is_heavy = command in HEAVY_COMMANDS
    if not is_heavy and update.callback_query and update.callback_query.data:
        is_heavy = update.callback_query.data.startswith(HEAVY_CALLBACK_PREFIXES)

    if is_heavy:
        recent = db.count_recent_requests(user.id, window_seconds=60)
        if recent >= config.MAX_REQUESTS_PER_MINUTE:
            warning = (
                "🛑 **KUOTA TERLAMPAUI**\n"
                f"`Batas:` {config.MAX_REQUESTS_PER_MINUTE} operasi/menit untuk tools & AI chat.\n"
                "Coba lagi sesaat lagi."
            )
            await _notify(update, warning)
            raise ApplicationHandlerStop


async def _notify(update: Update, text: str):
    try:
        if update.callback_query:
            await update.callback_query.answer(text.replace("**", "").replace("`", ""), show_alert=True)
        elif update.effective_message:
            await update.effective_message.reply_text(text, parse_mode="Markdown")
    except Exception as e:
        logger.warning(f"Gagal mengirim notifikasi rate limit: {e}")
