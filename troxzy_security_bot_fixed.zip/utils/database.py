"""
🗄️ TROXZY DATABASE ENGINE
Quantum-Encrypted SQLite Core
Badan_Intelijen_Negara Protocol
"""

import sqlite3
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, List, Any
import config

class QuantumDatabase:
    """Futuristic database handler with neural-link styling"""

    def __init__(self, db_path: str = config.DATABASE_PATH):
        self.db_path = db_path
        self._init_tables()

    def _get_connection(self):
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_tables(self):
        """Initialize all system tables"""
        with self._get_connection() as conn:
            cursor = conn.cursor()

            # Users table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS users (
                    user_id INTEGER PRIMARY KEY,
                    username TEXT,
                    full_name TEXT,
                    first_seen TEXT,
                    last_active TEXT,
                    plan_type TEXT DEFAULT 'free',
                    plan_expiry TEXT,
                    credits INTEGER DEFAULT 0,
                    is_banned INTEGER DEFAULT 0,
                    metadata TEXT
                )
            """)

            # AI Conversations table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS ai_chats (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    role TEXT,
                    content TEXT,
                    timestamp TEXT,
                    tokens_used INTEGER DEFAULT 0
                )
            """)

            # Payments table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS payments (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    amount INTEGER,
                    plan_type TEXT,
                    sender_name TEXT,
                    proof_image_id TEXT,
                    status TEXT DEFAULT 'pending',
                    created_at TEXT,
                    verified_at TEXT,
                    verified_by INTEGER
                )
            """)

            # Bug Bounty Programs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS bb_programs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT,
                    platform TEXT,
                    url TEXT,
                    scope TEXT,
                    bounty_range TEXT,
                    is_active INTEGER DEFAULT 1,
                    added_at TEXT
                )
            """)

            # Recon Results table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS recon_results (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    target TEXT,
                    tool_used TEXT,
                    result TEXT,
                    timestamp TEXT,
                    is_authorized INTEGER DEFAULT 1
                )
            """)

            # System Logs table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS system_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    level TEXT,
                    module TEXT,
                    message TEXT,
                    timestamp TEXT
                )
            """)

            # Broadcast History table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS broadcast_logs (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    admin_id INTEGER,
                    message TEXT,
                    total_targets INTEGER DEFAULT 0,
                    sent_count INTEGER DEFAULT 0,
                    blocked_count INTEGER DEFAULT 0,
                    failed_count INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'running',
                    started_at TEXT,
                    finished_at TEXT
                )
            """)

            conn.commit()

            # Migrasi ringan: tambahkan kolom baru ke tabel users jika belum ada
            # (dipakai oleh rate limiter di utils/rate_limiter.py)
            cursor.execute("PRAGMA table_info(users)")
            existing_cols = {row[1] for row in cursor.fetchall()}
            if "last_command_at" not in existing_cols:
                cursor.execute("ALTER TABLE users ADD COLUMN last_command_at TEXT")
            conn.commit()

    # ═══════════════════════════════════════
    # 👤 USER MANAGEMENT
    # ═══════════════════════════════════════
    def get_user(self, user_id: int) -> Optional[Dict]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def add_user(self, user_id: int, username: str, full_name: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            now = datetime.now().isoformat()
            cursor.execute("""
                INSERT OR IGNORE INTO users 
                (user_id, username, full_name, first_seen, last_active, plan_type)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (user_id, username, full_name, now, now, "free"))
            conn.commit()

    def update_activity(self, user_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET last_active = ? WHERE user_id = ?",
                (datetime.now().isoformat(), user_id)
            )
            conn.commit()

    def update_plan(self, user_id: int, plan_type: str, expiry: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE users SET plan_type = ?, plan_expiry = ? WHERE user_id = ?",
                (plan_type, expiry, user_id)
            )
            conn.commit()

    def get_user_plan(self, user_id: int) -> str:
        user = self.get_user(user_id)
        if not user:
            return "free"
        # Check expiry
        if user.get("plan_expiry"):
            expiry = datetime.fromisoformat(user["plan_expiry"])
            if expiry < datetime.now():
                self.update_plan(user_id, "free", "")
                return "free"
        return user.get("plan_type", "free")

    def get_all_active_user_ids(self) -> List[int]:
        """Semua user_id yang belum di-ban. Dipakai oleh fitur broadcast."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT user_id FROM users WHERE is_banned = 0")
            return [row["user_id"] for row in cursor.fetchall()]

    def ban_user(self, user_id: int) -> bool:
        """Menandai user sebagai banned. Mengembalikan True jika user ditemukan."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_banned = 1 WHERE user_id = ?", (user_id,))
            conn.commit()
            return cursor.rowcount > 0

    def unban_user(self, user_id: int) -> bool:
        """Melepas status banned dari user. Mengembalikan True jika user ditemukan."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("UPDATE users SET is_banned = 0 WHERE user_id = ?", (user_id,))
            conn.commit()
            return cursor.rowcount > 0

    def is_user_banned(self, user_id: int) -> bool:
        user = self.get_user(user_id)
        return bool(user and user.get("is_banned"))

    # ═══════════════════════════════════════
    # 🧠 AI CHAT MEMORY
    # ═══════════════════════════════════════
    def add_chat_message(self, user_id: int, role: str, content: str, tokens: int = 0):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO ai_chats (user_id, role, content, timestamp, tokens_used)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, role, content, datetime.now().isoformat(), tokens))
            conn.commit()

    def get_chat_history(self, user_id: int, limit: int = 20) -> List[Dict]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM ai_chats 
                WHERE user_id = ? 
                ORDER BY timestamp DESC 
                LIMIT ?
            """, (user_id, limit))
            rows = cursor.fetchall()
            return [dict(row) for row in reversed(rows)]

    def clear_chat_history(self, user_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("DELETE FROM ai_chats WHERE user_id = ?", (user_id,))
            conn.commit()

    # ═══════════════════════════════════════
    # 💰 PAYMENT MANAGEMENT
    # ═══════════════════════════════════════
    def add_payment(self, user_id: int, amount: int, plan_type: str, sender_name: str, proof_image_id: str = "") -> int:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO payments (user_id, amount, plan_type, sender_name, proof_image_id, status, created_at)
                VALUES (?, ?, ?, ?, ?, ?, ?)
            """, (user_id, amount, plan_type, sender_name, proof_image_id, "pending", datetime.now().isoformat()))
            conn.commit()
            return cursor.lastrowid

    def get_payment(self, payment_id: int) -> Optional[Dict]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM payments WHERE id = ?", (payment_id,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def verify_payment(self, payment_id: int, admin_id: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE payments 
                SET status = 'verified', verified_at = ?, verified_by = ?
                WHERE id = ?
            """, (datetime.now().isoformat(), admin_id, payment_id))
            conn.commit()

    def get_pending_payments(self) -> List[Dict]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM payments WHERE status = 'pending' ORDER BY created_at")
            return [dict(row) for row in cursor.fetchall()]

    # ═══════════════════════════════════════
    # 🎯 BUG BOUNTY DATA
    # ═══════════════════════════════════════
    def add_program(self, name: str, platform: str, url: str, scope: str, bounty_range: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT OR IGNORE INTO bb_programs (name, platform, url, scope, bounty_range, added_at)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (name, platform, url, scope, bounty_range, datetime.now().isoformat()))
            conn.commit()

    def get_programs(self, platform: str = None) -> List[Dict]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            if platform:
                cursor.execute("SELECT * FROM bb_programs WHERE platform = ? AND is_active = 1", (platform,))
            else:
                cursor.execute("SELECT * FROM bb_programs WHERE is_active = 1")
            return [dict(row) for row in cursor.fetchall()]

    def save_recon(self, user_id: int, target: str, tool: str, result: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO recon_results (user_id, target, tool_used, result, timestamp)
                VALUES (?, ?, ?, ?, ?)
            """, (user_id, target, tool, result, datetime.now().isoformat()))
            conn.commit()

    # ═══════════════════════════════════════
    # 🛡️ RATE LIMITING
    # ═══════════════════════════════════════
    def check_cooldown(self, user_id: int, cooldown_seconds: int) -> Optional[float]:
        """
        Cek apakah user masih dalam masa cooldown sejak command terakhirnya.
        Mengembalikan None jika BOLEH lanjut (dan langsung mencatat waktu sekarang
        sebagai command terbaru), atau jumlah detik sisa cooldown jika masih harus menunggu.
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT last_command_at FROM users WHERE user_id = ?", (user_id,))
            row = cursor.fetchone()
            now = datetime.now()
            if row and row["last_command_at"]:
                last = datetime.fromisoformat(row["last_command_at"])
                elapsed = (now - last).total_seconds()
                if elapsed < cooldown_seconds:
                    return cooldown_seconds - elapsed
            cursor.execute(
                "UPDATE users SET last_command_at = ? WHERE user_id = ?",
                (now.isoformat(), user_id)
            )
            conn.commit()
            return None

    def count_recent_requests(self, user_id: int, window_seconds: int = 60) -> int:
        """
        Menghitung jumlah aktivitas (recon + ai_chats) dalam window_seconds terakhir,
        dipakai untuk membatasi MAX_REQUESTS_PER_MINUTE.
        """
        with self._get_connection() as conn:
            cursor = conn.cursor()
            since = (datetime.now() - timedelta(seconds=window_seconds)).isoformat()
            cursor.execute(
                "SELECT COUNT(*) FROM recon_results WHERE user_id = ? AND timestamp > ?",
                (user_id, since)
            )
            recon_count = cursor.fetchone()[0]
            cursor.execute(
                "SELECT COUNT(*) FROM ai_chats WHERE user_id = ? AND role = 'user' AND timestamp > ?",
                (user_id, since)
            )
            chat_count = cursor.fetchone()[0]
            return recon_count + chat_count

    # ═══════════════════════════════════════
    # 📢 BROADCAST HISTORY
    # ═══════════════════════════════════════
    def start_broadcast(self, admin_id: int, message: str, total_targets: int) -> int:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO broadcast_logs (admin_id, message, total_targets, status, started_at)
                VALUES (?, ?, ?, 'running', ?)
            """, (admin_id, message, total_targets, datetime.now().isoformat()))
            conn.commit()
            return cursor.lastrowid

    def finish_broadcast(self, broadcast_id: int, sent: int, blocked: int, failed: int):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE broadcast_logs
                SET sent_count = ?, blocked_count = ?, failed_count = ?,
                    status = 'completed', finished_at = ?
                WHERE id = ?
            """, (sent, blocked, failed, datetime.now().isoformat(), broadcast_id))
            conn.commit()

    def get_broadcast_history(self, limit: int = 5) -> List[Dict]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "SELECT * FROM broadcast_logs ORDER BY started_at DESC LIMIT ?", (limit,)
            )
            return [dict(row) for row in cursor.fetchall()]

    # ═══════════════════════════════════════
    # 📊 STATISTICS
    # ═══════════════════════════════════════
    def get_stats(self) -> Dict[str, Any]:
        with self._get_connection() as conn:
            cursor = conn.cursor()
            stats = {}

            cursor.execute("SELECT COUNT(*) FROM users")
            stats["total_users"] = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM users WHERE plan_type != 'free'")
            stats["premium_users"] = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM payments WHERE status = 'verified'")
            stats["total_payments"] = cursor.fetchone()[0]

            cursor.execute("SELECT SUM(amount) FROM payments WHERE status = 'verified'")
            result = cursor.fetchone()[0]
            stats["total_revenue"] = result or 0

            cursor.execute("SELECT COUNT(*) FROM ai_chats")
            stats["total_ai_messages"] = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM recon_results")
            stats["total_recons"] = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM broadcast_logs WHERE status = 'completed'")
            stats["total_broadcasts"] = cursor.fetchone()[0]

            return stats

    def log(self, level: str, module: str, message: str):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO system_logs (level, module, message, timestamp)
                VALUES (?, ?, ?, ?)
            """, (level, module, message, datetime.now().isoformat()))
            conn.commit()

# Global instance
db = QuantumDatabase()
