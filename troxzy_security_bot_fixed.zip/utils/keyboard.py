"""
⌨️ TROXZY KEYBOARD ENGINE
Interactive Button System
Badan_Intelijen_Negara Protocol
"""

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
import config

def main_menu(plan_type: str = "free") -> InlineKeyboardMarkup:
    """Main dashboard menu with futuristic layout"""
    buttons = [
        [
            InlineKeyboardButton("🧠 NEURAL CHAT", callback_data="menu_ai"),
            InlineKeyboardButton("🛠️ TOOLKIT", callback_data="menu_tools")
        ],
        [
            InlineKeyboardButton("🎯 BUG BOUNTY", callback_data="menu_bugbounty"),
            InlineKeyboardButton("💰 PREMIUM", callback_data="menu_premium")
        ],
        [
            InlineKeyboardButton("📡 SYSTEM STATUS", callback_data="menu_status"),
            InlineKeyboardButton("👤 ABOUT", callback_data="menu_about")
        ]
    ]

    if plan_type in ["pro", "enterprise"]:
        buttons.insert(0, [InlineKeyboardButton("💎 PREMIUM DASHBOARD", callback_data="menu_vip")])

    return InlineKeyboardMarkup(buttons)

def back_button(target: str = "menu") -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 BACK", callback_data=f"menu_{target}")]
    ])

def tools_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔍 WHOIS", callback_data="tool_whois"),
            InlineKeyboardButton("🌐 DNS ENUM", callback_data="tool_dns")
        ],
        [
            InlineKeyboardButton("🛡️ HEADERS", callback_data="tool_headers"),
            InlineKeyboardButton("🔒 SSL CHECK", callback_data="tool_ssl")
        ],
        [
            InlineKeyboardButton("📡 PORT SCAN", callback_data="tool_ports"),
            InlineKeyboardButton("🔎 TECH DETECT", callback_data="tool_tech")
        ],
        [InlineKeyboardButton("🔙 BACK", callback_data="menu_main")]
    ])

def bugbounty_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📋 PROGRAMS", callback_data="bb_programs"),
            InlineKeyboardButton("🔍 RECON", callback_data="bb_recon")
        ],
        [
            InlineKeyboardButton("📝 REPORT", callback_data="bb_report"),
            InlineKeyboardButton("📊 SCOPE", callback_data="bb_scope")
        ],
        [
            InlineKeyboardButton("🏆 LEADERBOARD", callback_data="bb_leaderboard"),
            InlineKeyboardButton("📚 RESOURCES", callback_data="bb_resources")
        ],
        [InlineKeyboardButton("🔙 BACK", callback_data="menu_main")]
    ])

def payment_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🔓 BASIC - Rp 50k", callback_data="pay_basic"),
            InlineKeyboardButton("💎 PRO - Rp 150k", callback_data="pay_pro")
        ],
        [
            InlineKeyboardButton("👑 ENTERPRISE - Rp 500k", callback_data="pay_enterprise")
        ],
        [InlineKeyboardButton("🔙 BACK", callback_data="menu_main")]
    ])

def admin_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("📊 STATS", callback_data="admin_stats"),
            InlineKeyboardButton("💰 PAYMENTS", callback_data="admin_payments")
        ],
        [
            InlineKeyboardButton("📢 BROADCAST", callback_data="admin_broadcast"),
            InlineKeyboardButton("🚫 BAN USER", callback_data="admin_ban")
        ],
        [
            InlineKeyboardButton("📝 ADD PROGRAM", callback_data="admin_addprog"),
            InlineKeyboardButton("⚙️ SETTINGS", callback_data="admin_settings")
        ],
        [InlineKeyboardButton("🔙 BACK", callback_data="menu_main")]
    ])

def verify_payment_buttons(payment_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("✅ VERIFY", callback_data=f"verify_accept_{payment_id}"),
            InlineKeyboardButton("❌ REJECT", callback_data=f"verify_reject_{payment_id}")
        ]
    ])

def recon_options() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🌐 SUBDOMAINS", callback_data="bb_recon_subs"),
            InlineKeyboardButton("📡 PORTS", callback_data="bb_recon_ports")
        ],
        [
            InlineKeyboardButton("🔎 TECH STACK", callback_data="bb_recon_tech"),
            InlineKeyboardButton("🛡️ HEADERS", callback_data="bb_recon_headers")
        ],
        [
            InlineKeyboardButton("📸 SCREENSHOT", callback_data="bb_recon_screenshot"),
            InlineKeyboardButton("🗺️ SITEMAP", callback_data="bb_recon_sitemap")
        ],
        [InlineKeyboardButton("🔙 BACK", callback_data="menu_bugbounty")]
    ])

def ai_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup([
        [
            InlineKeyboardButton("🧠 NEW CHAT", callback_data="ai_new"),
            InlineKeyboardButton("🗑️ CLEAR MEMORY", callback_data="ai_clear")
        ],
        [
            InlineKeyboardButton("📊 TOKEN USAGE", callback_data="ai_tokens"),
            InlineKeyboardButton("⚙️ SETTINGS", callback_data="ai_settings")
        ],
        [InlineKeyboardButton("🔙 BACK", callback_data="menu_main")]
    ])
