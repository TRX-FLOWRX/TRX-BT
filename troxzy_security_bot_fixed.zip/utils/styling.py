"""
TROXZY UI STYLING ENGINE
Futuristic Visual System
Badan_Intelijen_Negara Protocol
"""

from typing import List

class QuantumStyling:
    """Advanced text styling for futuristic Telegram UI"""

    PALETTE = {
        "primary": "🔵",
        "success": "🟢",
        "warning": "🟡",
        "danger": "🔴",
        "info": "🟣",
        "neutral": "⚪",
        "gold": "🟠",
        "dark": "⚫"
    }

    BORDER_TOP = "╔══════════════════════════════════════╗"
    BORDER_BOT = "╚══════════════════════════════════════╝"
    BORDER_MID = "╠══════════════════════════════════════╣"
    DIVIDER = "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    THIN_DIV = "──────────────────────────────────────"

    @staticmethod
    def header(title: str, icon: str = "⚡") -> str:
        return icon + " **" + title + "**\n`" + QuantumStyling.DIVIDER + "`"

    @staticmethod
    def section(title: str, content: str, icon: str = "▸") -> str:
        return icon + " *" + title + "*\n" + content

    @staticmethod
    def code_block(content: str, lang: str = "") -> str:
        return "```" + lang + "\n" + content + "\n```"

    @staticmethod
    def status_badge(text: str, status: str = "active") -> str:
        icons = {"active": "🟢", "pending": "🟡", "error": "🔴", "premium": "💎", "free": "🔓", "admin": "👑"}
        return icons.get(status, "⚪") + " `" + text + "`"

    @staticmethod
    def progress_bar(current: int, total: int, length: int = 10) -> str:
        filled = int((current / total) * length) if total > 0 else 0
        bar = "█" * filled + "░" * (length - filled)
        percent = int((current / total) * 100) if total > 0 else 0
        return "`[" + bar + "] " + str(percent) + "%`"

    @staticmethod
    def matrix_rain() -> str:
        return "`01001000 01001001 01000100 01000100 01000101 01001110`"

    @staticmethod
    def typing_indicator() -> str:
        return "`⚡ Neural Link Establishing...`"

    @staticmethod
    def alert_box(title: str, message: str, level: str = "info") -> str:
        icons = {"info": "ℹ️", "warning": "⚠️", "danger": "🚨", "success": "✅"}
        return icons.get(level, "ℹ️") + " **" + title + "**\n\n" + message

    @staticmethod
    def data_card(label: str, value: str, unit: str = "") -> str:
        return "`" + label + "." * (20 - len(label)) + "` " + value + " " + unit

    @staticmethod
    def menu_item(number: int, title: str, desc: str, icon: str) -> str:
        return icon + " `" + str(number).zfill(2) + ".` *" + title + "*\n   ├─ " + desc

    @staticmethod
    def footer(creator: str = "Troxzy") -> str:
        return "`" + QuantumStyling.DIVIDER + "`\n👤 **Creator:** " + creator + "\n⚡ **Protocol:** Badan_Intelijen_Negara\n🔒 **Authorized Research Only**"

style = QuantumStyling()
