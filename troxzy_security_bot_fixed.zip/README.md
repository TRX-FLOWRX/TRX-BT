# 🚀 TROXZY SECURITY BOT v9.0

**Quantum-Neural Hybrid Intelligence System**  
**Creator:** Troxzy  
**Protocol:** Badan_Intelijen_Negara

---

## ⚡ FEATURES

- 🧠 **AI Neural Chat** — Powered by GLM-5.2 via FreeTheAI API
- 🛠️ **Security Toolkit** — WHOIS, DNS, Headers, SSL, Port Scan, Tech Detection
- 🎯 **Bug Bounty Dashboard** — Program tracking, reconnaissance, reports
- 💰 **Premium System** — QRIS GoPay payment with OCR verification
- 👑 **Admin Panel** — Statistics, payment verification, broadcast
- 🗄️ **SQLite Database** — Persistent storage for all operations
- 🎨 **Futuristic UI** — Matrix animations, progress bars, styled output

---

## 🛠️ DEPLOYMENT (PythonAnywhere)

1. Upload all files to PythonAnywhere
2. Install requirements: `pip install -r requirements.txt`
3. Install Tesseract OCR: `sudo apt-get install tesseract-ocr` (if supported)
4. Create `.env` file from `.env.example`
5. Fill in your BOT_TOKEN and AI_API_KEY
6. Run: `python main.py`

---

## ⚠️ DISCLAIMER

This bot is designed for **authorized security research** and **bug bounty programs** only. All tools must be used on systems you own or have explicit written permission to test. The creator is not responsible for misuse.

---

## 📡 SYSTEM REQUIREMENTS

- Python 3.9+
- Linux VPS / PythonAnywhere
- Internet connection
- Telegram Bot Token
- FreeTheAI API Key
