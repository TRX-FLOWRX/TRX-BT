"""
TROXZY SECURITY TOOLKIT
Reconnaissance & Analysis Tools
Badan_Intelijen_Negara Protocol
"""

import asyncio
import socket
import ssl
import dns.resolver
import whois
import aiohttp
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler

import config
from utils.database import db
from utils.styling import style
from utils.keyboard import tools_menu, back_button

TOOLS_WAITING_DOMAIN = 1

async def tools_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.update_activity(user.id)
    parts = [
        "🛠️ **SECURITY TOOLKIT**",
        "`" + style.DIVIDER + "`",
        "`Status:` 🟢 OPERATIONAL",
        "`Clearance:` AUTHORIZED RESEARCH ONLY",
        "",
        "**Available Modules:**",
        "• WHOIS Lookup — Domain registration data",
        "• DNS Enumeration — Record resolution",
        "• Security Headers — HTTP security analysis",
        "• SSL/TLS Check — Certificate validation",
        "• Port Scanner — Common port detection",
        "• Tech Detection — Stack fingerprinting",
        "",
        "`⚠️ DISCLAIMER:`",
        "Use only on domains you own or have written permission to test.",
        "",
        style.footer()
    ]
    await update.message.reply_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=tools_menu())

async def tools_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await tools_handler(update, context)

async def tools_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    tool_map = {"tool_whois": "WHOIS Lookup", "tool_dns": "DNS Enumeration", "tool_headers": "Security Headers", "tool_ssl": "SSL/TLS Check", "tool_ports": "Port Scanner", "tool_tech": "Tech Detection"}
    if data in tool_map:
        context.user_data["active_tool"] = data.replace("tool_", "")
        parts = ["🔧 **" + tool_map[data] + "**", "`" + style.DIVIDER + "`", "Enter target domain:", "`Format:` example.com", "`Note:` Do not include http:// or https://", "", "Send /cancel to abort."]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown")
        return TOOLS_WAITING_DOMAIN
    await query.edit_message_text("❌ Unknown tool", reply_markup=tools_menu())
    return ConversationHandler.END

async def whois_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    target = update.message.text.strip()
    tool = context.user_data.get("active_tool", "whois")
    if target in ["/cancel", "cancel"]:
        await update.message.reply_text("❌ Operation cancelled.", reply_markup=tools_menu())
        return ConversationHandler.END
    msg = await update.message.reply_text("`⚡ Executing " + tool + " on " + target + "...`", parse_mode="Markdown")
    try:
        if tool == "whois":
            await msg.edit_text("`🔍 Querying WHOIS database...`")
            await asyncio.sleep(0.5)
            try:
                w = whois.whois(target)
                ns = w.name_servers
                if isinstance(ns, list):
                    ns_str = ", ".join(ns)
                else:
                    ns_str = str(ns) if ns else "N/A"
                parts = [
                    "🔍 **WHOIS RESULT**",
                    "`" + style.DIVIDER + "`",
                    "`Domain:` " + target,
                    "`Registrar:` " + str(w.registrar or "N/A"),
                    "`Creation:` " + str(w.creation_date or "N/A"),
                    "`Expiration:` " + str(w.expiration_date or "N/A"),
                    "`Name Servers:` " + ns_str,
                    "`Status:` " + str(w.status or "N/A"),
                    "`Org:` " + str(w.org or "N/A"),
                    "`Country:` " + str(w.country or "N/A"),
                    "",
                    style.footer()
                ]
                result = "\n\n".join(parts)
            except Exception as e:
                result = "⚠️ WHOIS Error: " + str(e)[:200]
            await msg.edit_text(result, parse_mode="Markdown", reply_markup=back_button("tools"))
        elif tool == "dns":
            await msg.edit_text("`🌐 Resolving DNS records...`")
            await asyncio.sleep(0.5)
            records = {}
            for rtype in ["A", "AAAA", "MX", "NS", "TXT", "SOA", "CNAME"]:
                try:
                    answers = dns.resolver.resolve(target, rtype)
                    records[rtype] = [str(rdata) for rdata in answers]
                except:
                    records[rtype] = []
            parts = ["🌐 **DNS ENUMERATION**", "`" + style.DIVIDER + "`", "`Target:` " + target, ""]
            for rtype, values in records.items():
                if values:
                    parts.append("`" + rtype + ":`")
                    for v in values[:5]:
                        parts.append("  • " + v)
            parts.append("")
            parts.append(style.footer())
            await msg.edit_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("tools"))
        elif tool == "headers":
            await msg.edit_text("`🛡️ Analyzing headers...`")
            async with aiohttp.ClientSession() as session:
                async with session.get("https://" + target, timeout=aiohttp.ClientTimeout(total=10), headers=config.HEADERS_SECURITY, allow_redirects=True) as resp:
                    headers = dict(resp.headers)
                    parts = ["🛡️ **SECURITY HEADERS**", "`" + style.DIVIDER + "`", "`Target:` " + target, "`Status:` " + str(resp.status), "`URL:` " + str(resp.url), ""]
                    for h in ["Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy", "Permissions-Policy", "X-XSS-Protection"]:
                        val = headers.get(h, "❌ MISSING")
                        icon = "✅" if val != "❌ MISSING" else "❌"
                        parts.append(icon + " `" + h + ":` " + val)
                    parts.append("")
                    parts.append(style.footer())
                    await msg.edit_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("tools"))
        elif tool == "ssl":
            await msg.edit_text("`🔒 Checking SSL/TLS...`")
            try:
                context_ssl = ssl.create_default_context()
                with socket.create_connection((target, 443), timeout=5) as sock:
                    with context_ssl.wrap_socket(sock, server_hostname=target) as ssock:
                        cert = ssock.getpeercert()
                        cipher = ssock.cipher()
                        version = ssock.version()
                        parts = [
                            "🔒 **SSL/TLS ANALYSIS**",
                            "`" + style.DIVIDER + "`",
                            "`Target:` " + target,
                            "`Protocol:` " + str(version),
                            "`Cipher:` " + str(cipher[0] if cipher else "N/A"),
                            "`Subject:` " + str(cert.get("subject", "N/A")),
                            "`Issuer:` " + str(cert.get("issuer", "N/A")),
                            "`Not Before:` " + str(cert.get("notBefore", "N/A")),
                            "`Not After:` " + str(cert.get("notAfter", "N/A")),
                            "`Serial:` " + str(cert.get("serialNumber", "N/A")),
                            "",
                            style.footer()
                        ]
                        await msg.edit_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("tools"))
            except Exception as e:
                await msg.edit_text("⚠️ SSL Check Error: " + str(e)[:200], reply_markup=back_button("tools"))
        elif tool == "ports":
            await msg.edit_text("`📡 Scanning common ports...`")
            common_ports = {21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS", 80: "HTTP", 110: "POP3", 143: "IMAP", 443: "HTTPS", 3306: "MySQL", 3389: "RDP", 8080: "HTTP-Alt"}
            open_ports = []
            for port, service in common_ports.items():
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    if sock.connect_ex((target, port)) == 0:
                        open_ports.append(str(port) + "/" + service)
                    sock.close()
                except:
                    pass
                await asyncio.sleep(0.1)
            parts = ["📡 **PORT SCAN RESULT**", "`" + style.DIVIDER + "`", "`Target:` " + target, "`Scanned:` " + str(len(common_ports)) + " ports", "", "`Open Ports:`"]
            if open_ports:
                for p in open_ports:
                    parts.append("  🟢 " + p)
            else:
                parts.append("  ⚪ No common ports open (or filtered)")
            parts.append("")
            parts.append(style.footer())
            await msg.edit_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("tools"))
        elif tool == "tech":
            await msg.edit_text("`🔎 Fingerprinting technology...`")
            async with aiohttp.ClientSession() as session:
                async with session.get("https://" + target, timeout=aiohttp.ClientTimeout(total=10), headers=config.HEADERS_SECURITY) as resp:
                    headers = dict(resp.headers)
                    parts = ["🔎 **TECHNOLOGY DETECTION**", "`" + style.DIVIDER + "`", "`Target:` " + target, "`Status:` " + str(resp.status), ""]
                    tech_map = {"Server": headers.get("Server", "Unknown"), "X-Powered-By": headers.get("X-Powered-By", "Unknown"), "Via": headers.get("Via", "Unknown"), "X-Generator": headers.get("X-Generator", "Unknown"), "CF-RAY": "Cloudflare" if "CF-RAY" in headers else "Not detected", "X-Cache": headers.get("X-Cache", "Unknown"), "Set-Cookie": "Present" if "Set-Cookie" in headers else "None"}
                    for k, v in tech_map.items():
                        parts.append("`" + k + ":` " + v)
                    parts.append("")
                    parts.append(style.footer())
                    await msg.edit_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("tools"))
        db.save_recon(user.id, target, tool, "completed")
    except Exception as e:
        err_text = "💀 **TOOL ERROR**\n`" + style.DIVIDER + "`\n\n`Error:` " + str(e)[:300] + "\n\nCheck target validity and try again."
        await msg.edit_text(err_text, parse_mode="Markdown", reply_markup=back_button("tools"))
    return ConversationHandler.END

# Alias di bawah ini dipertahankan untuk kompatibilitas (jika ada modul lain yang
# meng-import-nya), tapi TIDAK didaftarkan di main.py karena whois_handler sudah
# menangani semua tool (whois/dns/headers/ssl/ports/tech) lewat context.user_data["active_tool"].
async def dns_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await whois_handler(update, context)

async def headers_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await whois_handler(update, context)

async def ssl_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    return await whois_handler(update, context)
