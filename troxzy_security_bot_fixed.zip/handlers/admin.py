"""
TROXZY ADMIN HANDLER
System Control & Management
Badan_Intelijen_Negara Protocol
"""

import asyncio
import logging
from telegram import Update
from telegram.error import Forbidden, BadRequest, RetryAfter, TelegramError
from telegram.ext import ContextTypes
from datetime import datetime

import config
from utils.database import db
from utils.styling import style
from utils.keyboard import admin_menu, back_button

logger = logging.getLogger(__name__)

# Jeda antar pengiriman broadcast. Bot API Telegram membatasi sekitar
# 30 pesan/detik secara global untuk chat berbeda; 0.05s (~20/detik)
# memberi margin aman tanpa membuat broadcast berjalan terlalu lambat.
BROADCAST_DELAY_SECONDS = 0.05
# Progress diperbarui setiap N pengiriman, supaya tidak membanjiri admin
# dengan terlalu banyak edit_text (dan supaya tidak kena rate limit edit pesan sendiri).
BROADCAST_PROGRESS_EVERY = 25

async def admin_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        parts = ["🚫 **ACCESS DENIED**", "`" + style.DIVIDER + "`", "`Clearance:` INSUFFICIENT", "`Required:` ADMIN_LEVEL", "", "This incident has been logged."]
        await update.message.reply_text("\n\n".join(parts), parse_mode="Markdown")
        return
    parts = [
        "👑 **ADMIN CONTROL PANEL**",
        "`" + style.DIVIDER + "`",
        "`Operator:` " + user.full_name,
        "`Clearance:` MAXIMUM",
        "`System:` " + config.BOT_NAME,
        "",
        "**Modules:**",
        "• Statistics — Global metrics",
        "• Payments — Verify pending transactions",
        "• Broadcast — Mass message delivery",
        "• User Management — Ban/unban operations",
        "• Program Manager — Add bounty programs",
        "",
        style.footer()
    ]
    await update.message.reply_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())

async def admin_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        await query.answer("🚫 ACCESS DENIED", show_alert=True)
        return
    if data == "admin_stats":
        stats = db.get_stats()
        parts = [
            "📊 **SYSTEM STATISTICS**",
            "`" + style.DIVIDER + "`",
            "`Users:` " + str(stats.get("total_users", 0)),
            "`Premium:` " + str(stats.get("premium_users", 0)),
            "`Revenue:` Rp " + str(stats.get("total_revenue", 0)),
            "`AI Msgs:` " + str(stats.get("total_ai_messages", 0)),
            "`Recon Ops:` " + str(stats.get("total_recons", 0)),
            "`Broadcasts:` " + str(stats.get("total_broadcasts", 0)),
            "",
            "`Timestamp:` " + datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())
    elif data == "admin_payments":
        pending = db.get_pending_payments()
        if not pending:
            await query.edit_message_text("💰 No pending payments.", reply_markup=admin_menu())
            return
        parts = ["💰 **PENDING PAYMENTS (" + str(len(pending)) + ")**", "`" + style.DIVIDER + "`", ""]
        for p in pending:
            parts.append("`ID:` #" + str(p["id"]))
            parts.append("`User:` " + str(p["user_id"]))
            parts.append("`Plan:` " + p["plan_type"])
            parts.append("`Amount:` Rp " + str(p["amount"]) + ",")
            parts.append("`Name:` " + p["sender_name"])
            parts.append("`Time:` " + p["created_at"])
            parts.append("")
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())
    elif data == "admin_broadcast":
        history = db.get_broadcast_history(limit=3)
        parts = ["📢 **BROADCAST**", "`" + style.DIVIDER + "`", "Use command:", "`/broadcast <message>`", "", "`⚠️ This sends to ALL active (non-banned) users. Use with caution.`"]
        if history:
            parts.append("")
            parts.append("`📜 Riwayat terakhir:`")
            for h in history:
                status_icon = "✅" if h["status"] == "completed" else "⏳"
                parts.append(f"{status_icon} #{h['id']} — {h['sent_count']}/{h['total_targets']} terkirim (`{h['status']}`)")
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())
    elif data == "admin_ban":
        parts = ["🚫 **USER MANAGEMENT**", "`" + style.DIVIDER + "`", "Commands:", "`/ban <user_id>`", "`/unban <user_id>`", "", "User yang di-ban tidak akan menerima broadcast dan tidak bisa memakai bot."]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())
    elif data == "admin_addprog":
        parts = ["📝 **ADD PROGRAM**", "`" + style.DIVIDER + "`", "Feature coming in v9.1", "Use database directly for now."]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())
    elif data == "admin_settings":
        parts = [
            "⚙️ **SETTINGS**",
            "`" + style.DIVIDER + "`",
            "`Bot Name:` " + config.BOT_NAME,
            "`Version:` " + config.VERSION,
            "`Model:` " + config.AI_MODEL,
            "`Admin IDs:` " + ", ".join(map(str, config.ADMIN_IDS)),
            "",
            "Settings locked in config.py"
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=admin_menu())

async def broadcast_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """
    Entry point command /broadcast <pesan>. Memvalidasi lalu MELEMPARKAN pekerjaan
    pengiriman ke background task (_run_broadcast) supaya bot tetap responsif
    terhadap update lain selama proses broadcast berjalan (bisa makan waktu lama
    kalau user banyak).
    """
    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        await update.message.reply_text("🚫 Access denied")
        return

    # Menangani baik "/broadcast pesan" maupun "/broadcast@NamaBot pesan"
    raw = update.message.text.split(None, 1)
    message = raw[1].strip() if len(raw) > 1 else ""
    if not message:
        await update.message.reply_text(
            "Usage: `/broadcast <message>`\n\n"
            "Pesan akan dikirim ke semua user aktif (yang belum di-ban).",
            parse_mode="Markdown"
        )
        return

    targets = db.get_all_active_user_ids()
    if not targets:
        await update.message.reply_text("⚠️ Tidak ada user aktif untuk dikirimi broadcast.")
        return

    broadcast_id = db.start_broadcast(user.id, message, len(targets))

    progress_msg = await update.message.reply_text(
        "\n\n".join([
            "📡 **BROADCAST DIMULAI**",
            "`" + style.DIVIDER + "`",
            f"`ID:` #{broadcast_id}",
            f"`Target:` {len(targets)} user",
            "`Progress:` " + style.progress_bar(0, len(targets)),
        ]),
        parse_mode="Markdown"
    )

    # Dijalankan lewat context.application.create_task() (bukan asyncio.create_task()
    # polos) supaya: (1) exception yang tidak tertangani di dalamnya otomatis diteruskan
    # ke error_handler global lewat process_error(), tidak hilang diam-diam; dan
    # (2) task ini ikut ditunggu dengan benar saat bot dimatikan (application.stop()).
    context.application.create_task(
        _run_broadcast(context, broadcast_id, message, targets, progress_msg),
        update=update
    )


async def _run_broadcast(context: ContextTypes.DEFAULT_TYPE, broadcast_id: int, message: str,
                          targets: list, progress_msg):
    """
    Background task yang benar-benar mengirim pesan ke setiap target.
    Membedakan 3 jenis kegagalan:
      - Forbidden   → user memblokir bot / menghapus akun (dihitung 'blocked')
      - BadRequest  → chat tidak valid/tidak ditemukan (dihitung 'failed')
      - RetryAfter  → kena flood limit Telegram, bot menunggu sesuai instruksi lalu retry sekali
      - Exception lain → dicatat sebagai 'failed', tidak menghentikan broadcast untuk target lain
    """
    sent, blocked, failed = 0, 0, 0
    total = len(targets)

    for i, target_id in enumerate(targets, 1):
        try:
            await context.bot.send_message(
                chat_id=target_id,
                text="📢 **PENGUMUMAN**\n" + style.DIVIDER + "\n\n" + message,
                parse_mode="Markdown"
            )
            sent += 1
        except RetryAfter as e:
            # Telegram secara eksplisit meminta bot menunggu sekian detik sebelum lanjut.
            await asyncio.sleep(e.retry_after + 1)
            try:
                await context.bot.send_message(
                    chat_id=target_id,
                    text="📢 **PENGUMUMAN**\n" + style.DIVIDER + "\n\n" + message,
                    parse_mode="Markdown"
                )
                sent += 1
            except Exception:
                failed += 1
        except Forbidden:
            # User memblokir bot, akun dihapus, atau chat privat tidak bisa dijangkau lagi.
            blocked += 1
        except BadRequest:
            # chat_id tidak valid / tidak ditemukan.
            failed += 1
        except TelegramError as e:
            logger.warning(f"Broadcast #{broadcast_id}: gagal kirim ke {target_id}: {e}")
            failed += 1
        except Exception as e:
            logger.error(f"Broadcast #{broadcast_id}: error tak terduga untuk {target_id}: {e}")
            failed += 1

        if i % BROADCAST_PROGRESS_EVERY == 0 or i == total:
            try:
                await progress_msg.edit_text(
                    "\n\n".join([
                        "📡 **BROADCAST BERJALAN**",
                        "`" + style.DIVIDER + "`",
                        f"`ID:` #{broadcast_id}",
                        "`Progress:` " + style.progress_bar(i, total),
                        f"`Terkirim:` {sent} | `Diblokir:` {blocked} | `Gagal:` {failed}",
                    ]),
                    parse_mode="Markdown"
                )
            except Exception:
                pass  # Pesan progress mungkin dihapus admin; tidak fatal, lanjutkan broadcast.

        await asyncio.sleep(BROADCAST_DELAY_SECONDS)

    db.finish_broadcast(broadcast_id, sent, blocked, failed)

    try:
        await progress_msg.edit_text(
            "\n\n".join([
                "✅ **BROADCAST SELESAI**",
                "`" + style.DIVIDER + "`",
                f"`ID:` #{broadcast_id}",
                f"`Total Target:` {total}",
                f"`✅ Terkirim:` {sent}",
                f"`🚫 Diblokir:` {blocked}",
                f"`⚠️ Gagal:` {failed}",
                "",
                style.footer()
            ]),
            parse_mode="Markdown"
        )
    except Exception:
        pass

async def stats_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        await update.message.reply_text("🚫 Access denied")
        return
    stats = db.get_stats()
    text = "📊 **QUICK STATS**\n`" + style.DIVIDER + "`\n\nUsers: " + str(stats.get("total_users", 0)) + "\nPremium: " + str(stats.get("premium_users", 0)) + "\nRevenue: Rp " + str(stats.get("total_revenue", 0)) + "\nAI: " + str(stats.get("total_ai_messages", 0)) + " msgs\nRecon: " + str(stats.get("total_recons", 0)) + " ops\nBroadcasts: " + str(stats.get("total_broadcasts", 0))
    await update.message.reply_text(text, parse_mode="Markdown")

async def ban_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        await update.message.reply_text("🚫 Access denied")
        return
    args = update.message.text.split()[1:]
    if not args or not args[0].lstrip("-").isdigit():
        await update.message.reply_text("Usage: `/ban <user_id>`", parse_mode="Markdown")
        return
    target_id = int(args[0])
    if target_id in config.ADMIN_IDS:
        await update.message.reply_text("🚫 Tidak bisa mem-ban sesama admin.")
        return
    if db.ban_user(target_id):
        await update.message.reply_text(f"✅ User `{target_id}` telah di-ban dan tidak akan menerima broadcast.", parse_mode="Markdown")
    else:
        await update.message.reply_text(f"⚠️ User `{target_id}` tidak ditemukan di database.", parse_mode="Markdown")

async def unban_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        await update.message.reply_text("🚫 Access denied")
        return
    args = update.message.text.split()[1:]
    if not args or not args[0].lstrip("-").isdigit():
        await update.message.reply_text("Usage: `/unban <user_id>`", parse_mode="Markdown")
        return
    target_id = int(args[0])
    if db.unban_user(target_id):
        await update.message.reply_text(f"✅ User `{target_id}` telah di-unban.", parse_mode="Markdown")
    else:
        await update.message.reply_text(f"⚠️ User `{target_id}` tidak ditemukan di database.", parse_mode="Markdown")
