"""
TROXZY START HANDLER
Main Dashboard & Initialization
Badan_Intelijen_Negara Protocol
"""

import asyncio
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes
from datetime import datetime

import config
from utils.database import db
from utils.styling import style
from utils.keyboard import main_menu

async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.add_user(user.id, user.username or "N/A", user.full_name)
    db.update_activity(user.id)
    plan = db.get_user_plan(user.id)
    plan_icon = "💎" if plan != "free" else "🔓"

    welcome_msg = await update.message.reply_text(
        "`⚡ Establishing Neural Link...`",
        parse_mode="Markdown"
    )

    await asyncio.sleep(0.5)
    await welcome_msg.edit_text("`🔐 Authenticating Identity...`")
    await asyncio.sleep(0.5)
    await welcome_msg.edit_text("`🧠 Loading Neural Core...`")
    await asyncio.sleep(0.5)

    dt_str = datetime.now().strftime("%Y-%m-%d %H:%M")
    matrix = style.matrix_rain()

    parts = [
        "🚀 **TROXZY SECURITY BOT**",
        "`" + style.DIVIDER + "`",
        "👤 **Operator:** `" + user.full_name + "`",
        "🆔 **ID:** `" + str(user.id) + "`",
        plan_icon + " **Plan:** `" + plan.upper() + "`",
        "📅 **Date:** `" + dt_str + "`",
        "",
        "`" + matrix + "`",
        "",
        "Welcome to the **Quantum-Neural Hybrid Intelligence System**.",
        "Authorized security research & bug bounty operations.",
        "",
        "⚡ **Creator:** " + config.CREATOR,
        "🔒 **Protocol:** Badan_Intelijen_Negara"
    ]
    banner_text = "\n\n".join(parts)

    await welcome_msg.edit_text(
        banner_text,
        parse_mode="Markdown",
        reply_markup=main_menu(plan)
    )

    try:
        cap = "🎯 **Mission Control Ready**\n`System: ONLINE`\n`Threat Level: NORMAL`"
        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=config.BANNER_IMAGE_URL,
            caption=cap
        )
    except Exception:
        pass

async def menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user = update.effective_user
    db.update_activity(user.id)
    plan = db.get_user_plan(user.id)

    data = query.data

    if data == "menu_main":
        parts = [
            "🚀 **MAIN DASHBOARD**",
            "`" + style.DIVIDER + "`",
            "Select operation module:",
            "",
            style.menu_item(1, "NEURAL CHAT", "AI-powered security assistant", "🧠"),
            style.menu_item(2, "TOOLKIT", "Reconnaissance & analysis tools", "🛠️"),
            style.menu_item(3, "BUG BOUNTY", "Bounty hunting dashboard", "🎯"),
            style.menu_item(4, "PREMIUM", "Upgrade access level", "💰"),
            style.menu_item(5, "SYSTEM", "Status & diagnostics", "📡"),
            "",
            style.footer()
        ]
        text = "\n\n".join(parts)
        await query.edit_message_text(
            text,
            parse_mode="Markdown",
            reply_markup=main_menu(plan)
        )

    elif data == "menu_ai":
        from handlers.ai_chat import ai_menu_callback
        await ai_menu_callback(update, context)

    elif data == "menu_tools":
        from handlers.tools import tools_menu_callback
        await tools_menu_callback(update, context)

    elif data == "menu_bugbounty":
        from handlers.bugbounty import bb_menu_callback
        await bb_menu_callback(update, context)

    elif data == "menu_premium":
        from handlers.payments import premium_menu_callback
        await premium_menu_callback(update, context)

    elif data == "menu_status":
        await status_callback(update, context)

    elif data == "menu_about":
        await about_callback(update, context)

    elif data == "menu_vip":
        await vip_dashboard(update, context)

async def about_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    parts = [
        "👤 **ABOUT CREATOR**",
        "`" + style.DIVIDER + "`",
        "🧑‍💻 **Name:** `" + config.CREATOR + "`",
        "🔬 **Role:** Security Researcher & Bot Architect",
        "🛡️ **Specialty:** Bug Bounty Intelligence",
        "⚡ **System:** Badan_Intelijen_Negara Protocol",
        "`" + style.DIVIDER + "`",
        "🤖 **Bot Information:**",
        "`Version:` " + config.VERSION,
        "`Release:` " + config.RELEASE_DATE,
        "`Core:` Quantum-Neural Hybrid",
        "`Status:` OPERATIONAL",
        "`" + style.DIVIDER + "`",
        "📌 **Disclaimer:**",
        "This bot is designed for **authorized security research** and **bug bounty programs** only.",
        "",
        style.footer()
    ]
    text = "\n\n".join(parts)
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu())

async def about_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await about_handler(update, context)

async def status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import psutil
    import time

    uptime = time.time() - psutil.boot_time()
    hours = int(uptime // 3600)
    minutes = int((uptime % 3600) // 60)

    cpu = psutil.cpu_percent(interval=1)
    mem = psutil.virtual_memory()
    disk = psutil.disk_usage('/')

    stats = db.get_stats()

    parts = [
        "📡 **SYSTEM DIAGNOSTICS**",
        "`" + style.DIVIDER + "`",
        "`🖥️ SERVER STATUS:`",
        style.data_card("CPU Usage", str(cpu) + "%", ""),
        style.data_card("Memory", str(mem.percent) + "%", "(" + str(mem.used // 1024 // 1024) + "MB)"),
        style.data_card("Disk", str(disk.percent) + "%", "(" + str(disk.used // 1024 // 1024 // 1024) + "GB)"),
        style.data_card("Uptime", str(hours) + "h " + str(minutes) + "m", ""),
        "`📊 BOT METRICS:`",
        style.data_card("Total Users", str(stats.get("total_users", 0)), ""),
        style.data_card("Premium Users", str(stats.get("premium_users", 0)), ""),
        style.data_card("Total Revenue", "Rp " + str(stats.get("total_revenue", 0)), ""),
        style.data_card("AI Messages", str(stats.get("total_ai_messages", 0)), ""),
        style.data_card("Recon Ops", str(stats.get("total_recons", 0)), ""),
        "`" + style.DIVIDER + "`",
        "🟢 **Status:** ALL SYSTEMS OPERATIONAL",
        "⚡ **Neural Link:** STABLE",
        "🔒 **Encryption:** QUANTUM-RESISTANT",
        "",
        style.footer()
    ]
    text = "\n\n".join(parts)
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=main_menu())

async def status_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await status_handler(update, context)

async def vip_dashboard(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    parts = [
        "💎 **PREMIUM DASHBOARD**",
        "`" + style.DIVIDER + "`",
        "🚀 **Welcome to Elite Access**",
        "",
        "`✅ Active Features:`",
        "• Unlimited AI Neural Chat",
        "• Advanced Reconnaissance Suite",
        "• Real-time Program Alerts",
        "• Custom Report Templates",
        "• Direct Admin Support",
        "",
        "`⚡ Performance:`",
        style.progress_bar(95, 100),
        "",
        "`🔒 Security Level:` MAXIMUM",
        "",
        style.footer()
    ]
    text = "\n\n".join(parts)
    await query.edit_message_text(
        text,
        parse_mode="Markdown",
        reply_markup=main_menu("enterprise")
    )
