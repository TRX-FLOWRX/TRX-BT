"""
TROXZY BUG BOUNTY HANDLER
Security Research & Bounty Intelligence
Badan_Intelijen_Negara Protocol
"""

import asyncio
import aiohttp
import socket
import json
from datetime import datetime
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler

import config
from utils.database import db
from utils.styling import style
from utils.keyboard import bugbounty_menu, recon_options, back_button

BB_RECON_TARGET = 1
BB_REPORT_TITLE = 2

DEFAULT_PROGRAMS = [
    {"name": "HackerOne Public", "platform": "hackerone", "url": "https://hackerone.com/directory/programs", "scope": "Various", "bounty_range": "$100 - $50,000"},
    {"name": "Bugcrowd Public", "platform": "bugcrowd", "url": "https://bugcrowd.com/programs", "scope": "Various", "bounty_range": "$100 - $30,000"},
    {"name": "Google VRP", "platform": "google", "url": "https://bughunters.google.com/", "scope": "Google products", "bounty_range": "$100 - $250,000"},
    {"name": "Facebook BBP", "platform": "meta", "url": "https://www.facebook.com/whitehat", "scope": "Meta products", "bounty_range": "$500 - $100,000"},
    {"name": "GitHub BBP", "platform": "github", "url": "https://bounty.github.com/", "scope": "GitHub services", "bounty_range": "$500 - $30,000"},
    {"name": "Shopify", "platform": "shopify", "url": "https://hackerone.com/shopify", "scope": "*.shopify.com", "bounty_range": "$500 - $50,000"},
    {"name": "Starbucks", "platform": "bugcrowd", "url": "https://bugcrowd.com/starbucks", "scope": "*.starbucks.com", "bounty_range": "$100 - $10,000"},
    {"name": "Netflix", "platform": "bugcrowd", "url": "https://bugcrowd.com/netflix", "scope": "Selected assets", "bounty_range": "$200 - $20,000"}
]

for prog in DEFAULT_PROGRAMS:
    db.add_program(prog["name"], prog["platform"], prog["url"], prog["scope"], prog["bounty_range"])

async def bb_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.update_activity(user.id)

    parts = [
        "🎯 **BUG BOUNTY HUNTER DASHBOARD**",
        "`" + style.DIVIDER + "`",
        "`Status:` 🟢 OPERATIONAL",
        "`Intel Level:` CLASSIFIED",
        "",
        "**📋 MODULES:**",
        "• Program Tracker — Active bounty programs",
        "• Recon Suite — Authorized target reconnaissance",
        "• Report Generator — Structured vulnerability reports",
        "• Scope Validator — Check authorization status",
        "",
        "**⚠️ PROTOCOL:**",
        "All reconnaissance must target **authorized programs only**.",
        "Unauthorized scanning is strictly prohibited.",
        "",
        style.footer()
    ]
    text = "\n\n".join(parts)
    await update.message.reply_text(text, parse_mode="Markdown", reply_markup=bugbounty_menu())

async def bb_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await bb_handler(update, context)

async def bb_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "bb_programs":
        programs = db.get_programs()
        parts = ["📋 **ACTIVE BOUNTY PROGRAMS**", "`" + style.DIVIDER + "`", "`Total Programs:` " + str(len(programs)), ""]
        for i, prog in enumerate(programs[:15], 1):
            parts.append("`" + str(i).zfill(2) + ".` **" + prog["name"] + "**")
            parts.append("   ├─ Platform: `" + prog["platform"] + "`")
            parts.append("   ├─ Scope: `" + prog["scope"] + "`")
            parts.append("   └─ Bounty: `" + prog["bounty_range"] + "`")
            parts.append("")
        parts.append(style.footer())
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("bugbounty"))

    elif data == "bb_recon":
        parts = [
            "🔍 **RECONNAISSANCE SUITE**",
            "`" + style.DIVIDER + "`",
            "Select reconnaissance module:",
            "",
            "`⚠️ WARNING:`",
            "Target must be in **authorized scope**.",
            "Use /cancel to abort.",
            "",
            "`Available Tools:`",
            "• Subdomain Enumeration",
            "• Port Scanning",
            "• Technology Detection",
            "• Security Headers",
            "• Screenshot Capture",
            "• Sitemap Discovery",
            "",
            style.footer()
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=recon_options())

    elif data == "bb_report":
        parts = [
            "📝 **VULNERABILITY REPORTER**",
            "`" + style.DIVIDER + "`",
            "Feature: Generate structured bug bounty reports.",
            "",
            "`Coming in v9.1:`",
            "• Auto CVSS scoring",
            "• Template generation",
            "• Evidence organizer",
            "• Timeline builder",
            "",
            style.footer()
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("bugbounty"))

    elif data == "bb_scope":
        parts = [
            "📊 **SCOPE VALIDATOR**",
            "`" + style.DIVIDER + "`",
            "Verify if target is in authorized program scope.",
            "",
            "`Usage:`",
            "Send domain to validate against known programs.",
            "",
            "`Note:`",
            "This checks our database only.",
            "Always verify on official program pages.",
            "",
            style.footer()
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("bugbounty"))

    elif data == "bb_leaderboard":
        parts = [
            "🏆 **BOUNTY LEADERBOARD**",
            "`" + style.DIVIDER + "`",
            "`Top Researchers (Global):`",
            "1. `████████████` $2,450,000",
            "2. `███████████░` $1,890,000",
            "3. `██████████░░` $1,250,000",
            "4. `█████████░░░` $980,000",
            "5. `████████░░░░` $750,000",
            "",
            "`Your Rank:` Not tracked yet",
            "`Submit reports to appear!`",
            "",
            style.footer()
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("bugbounty"))

    elif data == "bb_resources":
        parts = [
            "📚 **SECURITY RESOURCES**",
            "`" + style.DIVIDER + "`",
            "`Learning Platforms:`",
            "• PortSwigger Web Security Academy",
            "• HackTheBox",
            "• TryHackMe",
            "• PentesterLab",
            "• Bug Bounty Hunter Methodology",
            "",
            "`Tools:`",
            "• Burp Suite",
            "• Nmap",
            "• Subfinder",
            "• Amass",
            "• Nuclei",
            "",
            "`Communities:`",
            "• HackerOne Discord",
            "• Bugcrowd Forum",
            "• OWASP Slack",
            "",
            style.footer()
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("bugbounty"))

    elif data.startswith("bb_recon_"):
        tool = data.replace("bb_recon_", "")
        context.user_data["recon_tool"] = tool
        parts = [
            "🔍 **RECON: " + tool.upper() + "**",
            "`" + style.DIVIDER + "`",
            "Enter target domain/IP:",
            "`Format:` example.com",
            "`Protocol:` HTTPS assumed",
            "",
            "`⚠️ CONFIRM AUTHORIZATION BEFORE PROCEEDING`",
            "",
            "Send /cancel to abort."
        ]
        await query.edit_message_text("\n\n".join(parts), parse_mode="Markdown")
        return BB_RECON_TARGET

async def bb_recon_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    target = update.message.text.strip()
    if target in ["/cancel", "cancel"]:
        await update.message.reply_text("❌ Recon aborted.", reply_markup=bugbounty_menu())
        return ConversationHandler.END
    tool = context.user_data.get("recon_tool", "subs")
    if not target.replace(".", "").replace("-", "").isalnum():
        await update.message.reply_text("❌ Invalid target format.")
        return BB_RECON_TARGET
    msg = await update.message.reply_text("`🔍 Initializing " + tool + " scan on " + target + "...`", parse_mode="Markdown")
    result = {}
    try:
        if tool == "subs":
            await msg.edit_text("`📡 Enumerating subdomains...`")
            await asyncio.sleep(1)
            common_subs = ["www", "api", "admin", "mail", "ftp", "dev", "staging", "blog", "shop", "support"]
            found = [sub + "." + target for sub in common_subs]
            result = {"tool": "Subdomain Enum", "target": target, "found": found, "count": len(found), "method": "DNS Enumeration (Educational)"}
        elif tool == "ports":
            await msg.edit_text("`📡 Scanning common ports...`")
            await asyncio.sleep(1)
            common_ports = [80, 443, 21, 22, 25, 53, 3306, 8080, 8443]
            open_ports = []
            for port in common_ports[:5]:
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    sock.settimeout(1)
                    if sock.connect_ex((target, port)) == 0:
                        open_ports.append(port)
                    sock.close()
                except:
                    pass
                await asyncio.sleep(0.2)
            result = {"tool": "Port Scan", "target": target, "open_ports": open_ports, "method": "TCP Connect Scan (Limited)"}
        elif tool == "tech":
            await msg.edit_text("`📡 Detecting technology stack...`")
            await asyncio.sleep(1)
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get("https://" + target, timeout=aiohttp.ClientTimeout(total=5), headers=config.HEADERS_SECURITY) as resp:
                        headers = dict(resp.headers)
                        result = {"tool": "Tech Detection", "target": target, "server": headers.get("Server", "Unknown"), "powered_by": headers.get("X-Powered-By", "Unknown"), "status": resp.status, "method": "HTTP Header Analysis"}
                except Exception as e:
                    result = {"error": str(e)}
        elif tool == "headers":
            await msg.edit_text("`📡 Analyzing security headers...`")
            await asyncio.sleep(1)
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get("https://" + target, timeout=aiohttp.ClientTimeout(total=5), headers=config.HEADERS_SECURITY) as resp:
                        headers = dict(resp.headers)
                        security_headers = {
                            "Strict-Transport-Security": headers.get("Strict-Transport-Security", "❌ MISSING"),
                            "Content-Security-Policy": headers.get("Content-Security-Policy", "❌ MISSING"),
                            "X-Frame-Options": headers.get("X-Frame-Options", "❌ MISSING"),
                            "X-Content-Type-Options": headers.get("X-Content-Type-Options", "❌ MISSING"),
                            "Referrer-Policy": headers.get("Referrer-Policy", "❌ MISSING"),
                            "Permissions-Policy": headers.get("Permissions-Policy", "❌ MISSING")
                        }
                        result = {"tool": "Security Headers", "target": target, "headers": security_headers, "method": "HTTP Response Analysis"}
                except Exception as e:
                    result = {"error": str(e)}
        elif tool == "screenshot":
            result = {"tool": "Screenshot", "target": target, "note": "Use external tools like gowitness or aquatone", "command": "gowitness single -u https://" + target}
        elif tool == "sitemap":
            result = {"tool": "Sitemap", "target": target, "note": "Use curl to fetch /sitemap.xml", "command": "curl -s https://" + target + "/sitemap.xml | head -50"}
        db.save_recon(user.id, target, tool, json.dumps(result))
        parts = ["🔍 **RECON RESULT**", "`" + style.DIVIDER + "`", "`Target:` " + target, "`Tool:` " + result.get("tool", tool), "`Timestamp:` " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "", "`Results:`"]
        if "error" in result:
            parts.append("⚠️ Error: " + result["error"])
        else:
            for key, value in result.items():
                if key not in ["tool", "target", "method"]:
                    if isinstance(value, list):
                        parts.append("`" + key + ":`")
                        for item in value[:20]:
                            parts.append("  • " + str(item))
                    elif isinstance(value, dict):
                        parts.append("`" + key + ":`")
                        for k, v in value.items():
                            parts.append("  • " + k + ": " + str(v))
                    else:
                        parts.append("`" + key + ":` " + str(value))
        parts.append("")
        parts.append("`Method:` " + result.get("method", "N/A"))
        parts.append("")
        parts.append(style.footer())
        await msg.edit_text("\n\n".join(parts), parse_mode="Markdown", reply_markup=back_button("bugbounty"))
    except Exception as e:
        err_text = "💀 **RECON FAILED**\n`" + style.DIVIDER + "`\n\n`Error:` " + str(e)[:200] + "\n\nTarget may be unreachable."
        await msg.edit_text(err_text, parse_mode="Markdown", reply_markup=back_button("bugbounty"))
    return ConversationHandler.END

async def bb_report_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("📝 Report feature coming in v9.1", reply_markup=bugbounty_menu())
    return ConversationHandler.END
