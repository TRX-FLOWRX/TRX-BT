"""
TROXZY PAYMENT HANDLER
Premium Access & QRIS Verification
Badan_Intelijen_Negara Protocol
"""

import asyncio
from datetime import datetime, timedelta
from telegram import Update, InlineKeyboardMarkup, InlineKeyboardButton
from telegram.ext import ContextTypes, ConversationHandler

import config
from utils.database import db
from utils.styling import style
from utils.keyboard import payment_menu, back_button, verify_payment_buttons
from utils.ocr_verifier import extract_text_from_image, verify_payment_proof, format_verification_result

PAYMENT_WAITING = 1

PLANS = {
    "basic": {
        "name": "BASIC",
        "price": 50000,
        "duration_days": 30,
        "features": ["AI Chat (100 msgs/day)", "Basic Recon Tools", "Community Support"]
    },
    "pro": {
        "name": "PRO",
        "price": 150000,
        "duration_days": 30,
        "features": ["Unlimited AI Chat", "Advanced Recon Suite", "Bug Bounty Intel", "Priority Support"]
    },
    "enterprise": {
        "name": "ENTERPRISE",
        "price": 500000,
        "duration_days": 90,
        "features": ["Everything in PRO", "Custom Tools", "Admin Panel", "API Access", "Direct Contact"]
    }
}

async def payment_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    db.update_activity(user.id)

    parts = [
        "💰 **PREMIUM ACCESS**",
        "`" + style.DIVIDER + "`",
        "Upgrade your security operations:",
        "",
        "🔓 **BASIC** — Rp 50.000/month",
        "• AI Chat (100 msgs/day)",
        "• Basic Recon Tools",
        "• Community Support",
        "",
        "💎 **PRO** — Rp 150.000/month",
        "• Unlimited AI Chat",
        "• Advanced Recon Suite",
        "• Bug Bounty Intelligence",
        "• Priority Support",
        "",
        "👑 **ENTERPRISE** — Rp 500.000/3months",
        "• Everything in PRO",
        "• Custom Tool Development",
        "• Admin Panel Access",
        "• API Integration",
        "• Direct Creator Contact",
        "",
        "`" + style.DIVIDER + "`",
        "",
        "Select plan to proceed:"
    ]
    text = "\n\n".join(parts)

    await update.message.reply_text(
        text,
        parse_mode="Markdown",
        reply_markup=payment_menu()
    )

async def premium_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    await payment_handler(update, context)

async def payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user = update.effective_user
    plan_key = query.data.replace("pay_", "")

    if plan_key not in PLANS:
        await query.edit_message_text("❌ Invalid plan selection")
        return ConversationHandler.END

    plan = PLANS[plan_key]

    context.user_data["selected_plan"] = plan_key
    context.user_data["plan_price"] = plan["price"]

    parts = [
        "💰 **PAYMENT INSTRUCTIONS**",
        "`" + style.DIVIDER + "`",
        "📋 **Plan:** " + plan["name"],
        "💵 **Amount:** Rp " + str(plan["price"]) + ",",
        "⏱️ **Duration:** " + str(plan["duration_days"]) + " days",
        "",
        "`✅ Features:`"
    ]
    for feat in plan["features"]:
        parts.append("• " + feat)
    parts.extend([
        "",
        "`" + style.DIVIDER + "`",
        "",
        "📝 **STEP 1:** Send payment via QRIS GoPay",
        "📝 **STEP 2:** Include your **FULL NAME** in transaction note",
        "📝 **STEP 3:** Send screenshot proof here",
        "",
        "`⚠️ IMPORTANT:`",
        "You MUST include your real name in the bank transaction note for verification.",
        "",
        "`QRIS Code:`"
    ])
    text = "\n\n".join(parts)

    await query.edit_message_text(
        text,
        parse_mode="Markdown",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("📸 SEND PROOF", callback_data="pay_upload")],
            [InlineKeyboardButton("🔙 BACK", callback_data="menu_premium")]
        ])
    )

    try:
        cap = "`📱 SCAN QRIS GOPAY`\n`Amount: Rp " + str(plan["price"]) + ",`\n`Plan: " + plan["name"] + "`"
        await context.bot.send_photo(
            chat_id=update.effective_chat.id,
            photo=config.QRIS_IMAGE_URL,
            caption=cap
        )
    except Exception:
        pass

    return PAYMENT_WAITING

async def submit_proof_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user

    if "selected_plan" not in context.user_data:
        await update.message.reply_text("❌ No active payment session. Use /buy to start.")
        return ConversationHandler.END

    plan_key = context.user_data["selected_plan"]
    plan = PLANS[plan_key]

    sender_name = "Unknown"
    if update.message.caption:
        sender_name = update.message.caption.strip()
    elif update.message.text:
        sender_name = update.message.text.strip()

    if not sender_name or sender_name == "Unknown":
        parts = [
            "⚠️ **NAME REQUIRED**",
            "`" + style.DIVIDER + "`",
            "You must include your **FULL NAME** in the message caption or text.",
            "",
            "`Format:`",
            "Send photo with caption: `Your Full Name`",
            "",
            "This is required for bank verification."
        ]
        await update.message.reply_text("\n\n".join(parts), parse_mode="Markdown")
        return PAYMENT_WAITING

    proof_image_id = None
    ocr_result = None

    if update.message.photo:
        photo = update.message.photo[-1]
        proof_image_id = photo.file_id
        try:
            file = await context.bot.get_file(proof_image_id)
            image_bytes = await file.download_as_bytearray()
            extracted_text = extract_text_from_image(bytes(image_bytes))
            ocr_result = verify_payment_proof(extracted_text, sender_name, plan["price"])
            ocr_text = format_verification_result(ocr_result)
            await update.message.reply_text(
                ocr_text + "\n\n`⏳ Waiting for admin verification...`",
                parse_mode="Markdown"
            )
        except Exception as e:
            await update.message.reply_text(
                "`⚠️ OCR Scan failed: " + str(e)[:100] + "`\n\n`⏳ Manual verification required...`",
                parse_mode="Markdown"
            )

    payment_id = db.add_payment(
        user_id=user.id,
        amount=plan["price"],
        plan_type=plan_key,
        sender_name=sender_name,
        proof_image_id=proof_image_id or ""
    )

    parts = [
        "✅ **PAYMENT SUBMITTED**",
        "`" + style.DIVIDER + "`",
        "`ID:` #" + str(payment_id),
        "`Plan:` " + plan["name"],
        "`Amount:` Rp " + str(plan["price"]) + ",",
        "`Name:` " + sender_name,
        "`Status:` ⏳ PENDING VERIFICATION",
        "",
        "Admin will verify your payment within 24 hours.",
        "You will be notified once approved.",
        "",
        style.footer()
    ]
    await update.message.reply_text("\n\n".join(parts), parse_mode="Markdown")

    for admin_id in config.ADMIN_IDS:
        try:
            admin_parts = [
                "🚨 **NEW PAYMENT PROOF**",
                "`" + style.DIVIDER + "`",
                "`ID:` #" + str(payment_id),
                "`User:` " + user.full_name + " (@" + (user.username or "N/A") + ")",
                "`User ID:` " + str(user.id),
                "`Plan:` " + plan["name"],
                "`Amount:` Rp " + str(plan["price"]) + ",",
                "`Sender Name:` " + sender_name,
            ]
            if ocr_result:
                admin_parts.append("`OCR Result:` " + str(ocr_result.get("valid", "N/A")))
                admin_parts.append("`Confidence:` " + str(int(ocr_result.get("confidence", 0) * 100)) + "%")
            else:
                admin_parts.append("`OCR Result:` N/A")
            admin_parts.append("`Time:` " + datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            admin_text = "\n\n".join(admin_parts)

            if proof_image_id:
                await context.bot.send_photo(
                    chat_id=admin_id,
                    photo=proof_image_id,
                    caption=admin_text,
                    parse_mode="Markdown",
                    reply_markup=verify_payment_buttons(payment_id)
                )
            else:
                await context.bot.send_message(
                    chat_id=admin_id,
                    text=admin_text,
                    parse_mode="Markdown",
                    reply_markup=verify_payment_buttons(payment_id)
                )
        except Exception:
            pass

    return ConversationHandler.END

async def verify_payment_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    user = update.effective_user
    if user.id not in config.ADMIN_IDS:
        await query.answer("❌ Unauthorized", show_alert=True)
        return

    data = query.data
    action = data.split("_")[1]
    payment_id = int(data.split("_")[2])
    payment = db.get_payment(payment_id)

    if not payment:
        await query.edit_message_text("❌ Payment not found")
        return

    if action == "accept":
        db.verify_payment(payment_id, user.id)
        plan = PLANS[payment["plan_type"]]
        expiry = datetime.now() + timedelta(days=plan["duration_days"])
        db.update_plan(payment["user_id"], payment["plan_type"], expiry.isoformat())

        try:
            parts = [
                "🎉 **PAYMENT VERIFIED!**",
                "`" + style.DIVIDER + "`",
                "✅ Your payment has been approved!",
                "",
                "`Plan:` " + plan["name"],
                "`Expiry:` " + expiry.strftime("%Y-%m-%d %H:%M"),
                "",
                "Welcome to premium access. Use /menu to explore.",
                "",
                style.footer()
            ]
            await context.bot.send_message(
                chat_id=payment["user_id"],
                text="\n\n".join(parts),
                parse_mode="Markdown"
            )
        except Exception:
            pass

        await query.edit_message_text("✅ Payment #" + str(payment_id) + " verified by " + user.full_name)

    else:
        with db._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute(
                "UPDATE payments SET status = 'rejected', verified_by = ?, verified_at = ? WHERE id = ?",
                (user.id, datetime.now().isoformat(), payment_id)
            )
            conn.commit()

        try:
            await context.bot.send_message(
                chat_id=payment["user_id"],
                text="❌ **PAYMENT REJECTED**\n\nYour payment proof was rejected.\n\nPossible reasons:\n• Name mismatch\n• Amount incorrect\n• Screenshot unclear\n\nPlease resubmit with /buy"
            )
        except Exception:
            pass

        await query.edit_message_text("❌ Payment #" + str(payment_id) + " rejected by " + user.full_name)
