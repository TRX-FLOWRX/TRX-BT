"""
🧠 TROXZY AI CHAT HANDLER
Neural Link with GLM-5.2 via FreeTheAI
Badan_Intelijen_Negara Protocol
"""

import asyncio
import aiohttp
import json
from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler

import config
from utils.database import db
from utils.styling import style
from utils.keyboard import ai_menu, back_button

# Conversation states
AI_CHATTING = 1

async def ai_chat_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Handle AI chat command"""
    user = update.effective_user
    db.update_activity(user.id)

    # Check if user provided text with command
    text = update.message.text.replace("/ai", "").strip()

    if not text:
        # Show AI menu
        await update.message.reply_text(
            f"""🧠 **NEURAL CHAT INTERFACE**
`{style.DIVIDER}`

Welcome to the **Quantum Neural Link**.
Connected to: `GLM-5.2` via FreeTheAI

`Usage:`
`/ai <your question>`

`Example:`
`/ai How to find XSS vulnerabilities?`

`Status:` 🟢 ONLINE
`Latency:` < 500ms
`Model:` {config.AI_MODEL}

{style.footer()}
""",
            parse_mode="Markdown",
            reply_markup=ai_menu()
        )
        return

    await process_ai_message(update, context, text)

async def process_ai_message(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str):
    """Process message with AI API"""
    user = update.effective_user

    # Show typing indicator
    thinking_msg = await update.message.reply_text(
        f"`🧠 Neural Processing...`",
        parse_mode="Markdown"
    )

    # Get conversation history
    history = db.get_chat_history(user.id, limit=10)
    messages = []

    # System prompt - focused on security research
    system_prompt = """You are Troxzy Security AI, an advanced cybersecurity assistant specializing in bug bounty hunting, penetration testing, and security research. You provide detailed, technical, and actionable advice for authorized security testing only. You never assist with illegal activities, unauthorized access, or malicious attacks. Focus on defensive security, vulnerability analysis, and responsible disclosure."""

    messages.append({"role": "system", "content": system_prompt})

    for msg in history:
        messages.append({
            "role": msg["role"],
            "content": msg["content"]
        })

    messages.append({"role": "user", "content": text})

    try:
        async with aiohttp.ClientSession() as session:
            payload = {
                "model": config.AI_MODEL,
                "messages": messages,
                "max_tokens": config.AI_MAX_TOKENS,
                "temperature": config.AI_TEMPERATURE
            }

            headers = {
                "Authorization": f"Bearer {config.AI_API_KEY}",
                "Content-Type": "application/json"
            }

            async with session.post(
                f"{config.AI_BASE_URL}/chat/completions",
                json=payload,
                headers=headers,
                timeout=aiohttp.ClientTimeout(total=60)
            ) as response:

                if response.status == 200:
                    data = await response.json()
                    ai_response = data["choices"][0]["message"]["content"]
                    tokens_used = data.get("usage", {}).get("total_tokens", 0)

                    # Save to database
                    db.add_chat_message(user.id, "user", text, 0)
                    db.add_chat_message(user.id, "assistant", ai_response, tokens_used)

                    # Format response
                    response_text = f"""🧠 **NEURAL RESPONSE**
`{style.DIVIDER}`

{ai_response}

`{style.DIVIDER}`
`Tokens:` {tokens_used} | `Model:` {config.AI_MODEL} | `Latency:` OK
"""

                    await thinking_msg.edit_text(
                        response_text,
                        parse_mode="Markdown",
                        reply_markup=ai_menu()
                    )
                else:
                    error_text = await response.text()
                    await thinking_msg.edit_text(
                        f"""💀 **NEURAL LINK ERROR**
`{style.DIVIDER}`

`Status:` {response.status}
`Error:` API Connection Failed

Retry or contact admin.
""",
                        parse_mode="Markdown"
                    )

    except Exception as e:
        await thinking_msg.edit_text(
            f"""💀 **SYSTEM ANOMALY**
`{style.DIVIDER}`

`Error:` {str(e)[:100]}

Neural link temporarily unstable.
""",
            parse_mode="Markdown"
        )

async def ai_clear_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Clear AI conversation memory"""
    user = update.effective_user
    db.clear_chat_history(user.id)

    await update.message.reply_text(
        f"""🗑️ **MEMORY WIPE COMPLETE**
`{style.DIVIDER}`

All conversation history has been purged.
Neural link reset to factory state.

`Status:` 🟢 READY FOR NEW SESSION
""",
        parse_mode="Markdown",
        reply_markup=ai_menu()
    )

async def ai_status_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Check AI system status"""
    user = update.effective_user
    history = db.get_chat_history(user.id)
    total_tokens = sum(msg.get("tokens_used", 0) for msg in history)

    text = f"""📊 **NEURAL LINK STATUS**
`{style.DIVIDER}`

`Model:` {config.AI_MODEL}
`Base URL:` {config.AI_BASE_URL}
`Status:` 🟢 OPERATIONAL

`Session Metrics:`
{style.data_card("Messages", len(history), "")}
{style.data_card("Total Tokens", total_tokens, "")}
{style.data_card("Memory Slots", 20 - len(history), "remaining")}

`{style.DIVIDER}`

Neural core running at optimal capacity.
"""

    # ai_status_handler bisa dipanggil dari command /ai_status (update.message ada)
    # ATAU dari tombol callback "TOKEN USAGE" di ai_menu_callback (update.message = None,
    # yang tersedia hanyalah update.callback_query). Cek dulu supaya tidak AttributeError.
    if update.callback_query:
        await update.callback_query.edit_message_text(
            text, parse_mode="Markdown", reply_markup=ai_menu()
        )
    else:
        await update.message.reply_text(
            text, parse_mode="Markdown", reply_markup=ai_menu()
        )

async def ai_menu_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """AI menu from callback"""
    query = update.callback_query
    await query.answer()

    if query.data == "ai_new":
        await query.edit_message_text(
            f"""🧠 **NEURAL CHAT READY**
`{style.DIVIDER}`

Type your message using:
`/ai <question>`

The quantum core is listening...
""",
            parse_mode="Markdown",
            reply_markup=ai_menu()
        )

    elif query.data == "ai_clear":
        user = update.effective_user
        db.clear_chat_history(user.id)
        await query.edit_message_text(
            f"""🗑️ **MEMORY PURGED**
`{style.DIVIDER}`

Neural memory wiped successfully.
Ready for new operations.
""",
            parse_mode="Markdown",
            reply_markup=ai_menu()
        )

    elif query.data == "ai_tokens":
        await ai_status_handler(update, context)

    elif query.data == "ai_settings":
        await query.edit_message_text(
            f"""⚙️ **AI CONFIGURATION**
`{style.DIVIDER}`

`Model:` {config.AI_MODEL}
`Temperature:` {config.AI_TEMPERATURE}
`Max Tokens:` {config.AI_MAX_TOKENS}
`Provider:` FreeTheAI

Settings are locked by admin.
""",
            parse_mode="Markdown",
            reply_markup=ai_menu()
        )
