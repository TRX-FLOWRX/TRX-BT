#!/usr/bin/env python3
"""
╔═══════════════════════════════════════════════════════════════╗
║  ⚡ TROXZY SECURITY BOT v9.0 ⚡                               ║
║  Quantum-Neural Hybrid Intelligence System                     ║
║  Creator: Troxzy | Badan_Intelijen_Negara Protocol           ║
║  Mode: Authorized Bug Bounty & Security Research               ║
╚═══════════════════════════════════════════════════════════════╝
"""

import asyncio
import logging
import sys
from datetime import datetime

from telegram import Update, BotCommand, BotCommandScopeDefault, BotCommandScopeChat
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    CallbackQueryHandler,
    ConversationHandler,
    filters,
    ContextTypes,
    ApplicationHandlerStop
)

import config
from handlers.start import start_handler, menu_callback, about_handler, status_handler
from handlers.ai_chat import ai_chat_handler, ai_clear_handler, ai_status_handler
from handlers.payments import (
    payment_handler, 
    payment_callback, 
    submit_proof_handler,
    verify_payment_callback,
    PAYMENT_WAITING
)
from handlers.bugbounty import (
    bb_handler,
    bb_callback,
    bb_recon_handler,
    bb_report_handler,
    BB_RECON_TARGET,
    BB_REPORT_TITLE
)
from handlers.tools import (
    tools_handler,
    tools_callback,
    whois_handler,
    TOOLS_WAITING_DOMAIN
)
from handlers.admin import admin_handler, admin_callback, broadcast_handler, stats_handler, ban_handler, unban_handler
from utils.rate_limiter import rate_limit_middleware

# ═══════════════════════════════════════════
# 🚀 LOGGING CONFIGURATION
# ═══════════════════════════════════════════
logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
    handlers=[
        logging.FileHandler("troxzy_bot.log"),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

# ═══════════════════════════════════════════
# 🎭 ANIMATION HELPERS
# ═══════════════════════════════════════════
async def typing_animation(update: Update, frames: list, duration: float = 0.3):
    """Simulate futuristic typing animation"""
    message = await update.message.reply_text(f"{frames[0]} Initializing...")
    for frame in frames[1:]:
        await asyncio.sleep(duration)
        await message.edit_text(f"{frame} Processing...")
    await message.delete()
    return message

# ═══════════════════════════════════════════
# 🛡️ ERROR HANDLER
# ═══════════════════════════════════════════
async def error_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Global error handler with futuristic logging"""
    logger.error(f"⚠️ EXCEPTION: {context.error}", exc_info=True)
    if update and update.effective_message:
        await update.effective_message.reply_text(
            f"""💀 **SYSTEM ANOMALY DETECTED**

`ERROR_ID: {datetime.now().strftime('%H%M%S%f')[:9]}`
`SEVERITY: CRITICAL`

The neural link encountered interference.
Mission aborted. Retry or contact admin.

🔧 **Troxzy** | Badan_Intelijen_Negara""",
            parse_mode="Markdown"
        )

# ═══════════════════════════════════════════
# 🌐 BOT COMMANDS SETUP
# ═══════════════════════════════════════════
async def post_init(application: Application):
    """Set bot commands menu — command umum untuk semua user, command admin
    hanya ditampilkan di menu masing-masing admin (BotCommandScopeChat)."""
    public_commands = [
        BotCommand("start", "🚀 Initialize System"),
        BotCommand("menu", "📊 Main Dashboard"),
        BotCommand("ai", "🧠 Neural Chat"),
        BotCommand("tools", "🛠️ Security Toolkit"),
        BotCommand("bugbounty", "🎯 Bounty Hunter"),
        BotCommand("buy", "💰 Access Premium"),
        BotCommand("status", "📡 System Status"),
        BotCommand("about", "👤 About Troxzy"),
        BotCommand("help", "❓ Command List"),
    ]
    await application.bot.set_my_commands(public_commands, scope=BotCommandScopeDefault())

    admin_commands = public_commands + [
        BotCommand("admin", "👑 Admin Panel"),
        BotCommand("stats", "📊 Quick Stats"),
        BotCommand("broadcast", "📢 Broadcast Message"),
        BotCommand("ban", "🚫 Ban User"),
        BotCommand("unban", "✅ Unban User"),
    ]
    for admin_id in config.ADMIN_IDS:
        try:
            await application.bot.set_my_commands(admin_commands, scope=BotCommandScopeChat(chat_id=admin_id))
        except Exception as e:
            # Wajar terjadi kalau admin belum pernah /start bot-nya sama sekali
            # (Telegram menolak set scope untuk chat yang belum pernah dibuka).
            logger.warning(f"Tidak bisa set command menu khusus untuk admin {admin_id}: {e}")

    logger.info("✅ Bot commands initialized")

# ═══════════════════════════════════════════
# ❓ HELP HANDLER
# ═══════════════════════════════════════════
async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Comprehensive help menu"""
    user = update.effective_user
    help_text = f"""🚀 **TROXZY SECURITY BOT v{config.VERSION}**
━━━━━━━━━━━━━━━━━━━━━━

**🧠 AI COMMANDS**
`/ai <text>` — Neural chat with GLM-5.2
`/ai_clear` — Wipe conversation memory
`/ai_status` — Check neural link status

**🛠️ RECONNAISSANCE TOOLS**
`/tools` — Open Security Toolkit
• WHOIS Lookup
• DNS Enumeration  
• Security Headers Check
• SSL/TLS Analyzer

**🎯 BUG BOUNTY**
`/bugbounty` — Bounty Hunter Dashboard
• Program Tracker
• Reconnaissance Suite
• Report Generator
• Scope Validator

**💰 PREMIUM ACCESS**
`/buy` — Purchase subscription plans
• Basic (Rp 50.000)
• Pro (Rp 150.000)
• Enterprise (Rp 500.000)

**📡 SYSTEM**
`/status` — Bot health & metrics
`/about` — Creator information
`/menu` — Return to main dashboard
"""
    if user and user.id in config.ADMIN_IDS:
        help_text += """
**👑 ADMIN COMMANDS**
`/admin` — Admin control panel
`/stats` — Quick statistics
`/broadcast <msg>` — Kirim pesan ke semua user aktif
`/ban <user_id>` — Ban user
`/unban <user_id>` — Unban user
"""
    help_text += f"""
━━━━━━━━━━━━━━━━━━━━━━
🔒 **Authorized Security Research Only**
👤 **Creator:** {config.CREATOR}
⚡ **Protocol:** Badan_Intelijen_Negara
"""
    await update.message.reply_text(help_text, parse_mode="Markdown")

# ═══════════════════════════════════════════
# 🔄 MENU HANDLER
# ═══════════════════════════════════════════
async def menu_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """Redirect to main menu"""
    await start_handler(update, context)

# ═══════════════════════════════════════════
# 🚀 MAIN ENTRY POINT
# ═══════════════════════════════════════════
def main():
    """Initialize the quantum system"""
    print(f"""
    ╔═══════════════════════════════════════════════════════════════╗
    ║  ⚡ TROXZY SECURITY BOT v{config.VERSION} ⚡                    ║
    ║  Initializing Quantum-Neural Hybrid Core...                  ║
    ║  Creator: {config.CREATOR}                                    ║
    ║  Protocol: Badan_Intelijen_Negara                             ║
    ╚═══════════════════════════════════════════════════════════════╝
    """)

    application = (
        Application.builder()
        .token(config.BOT_TOKEN)
        .post_init(post_init)
        .build()
    )

    # ═══════════════════════════════════════
    # 📋 CONVERSATION HANDLERS
    # ═══════════════════════════════════════
    # Payment proof submission flow
    payment_conv = ConversationHandler(
        entry_points=[
            CallbackQueryHandler(payment_callback, pattern="^pay_"),
            CommandHandler("buy", payment_handler)
        ],
        states={
            PAYMENT_WAITING: [
                MessageHandler(filters.PHOTO, submit_proof_handler),
                MessageHandler(filters.TEXT & ~filters.COMMAND, submit_proof_handler)
            ]
        },
        fallbacks=[CommandHandler("cancel", lambda u, c: u.message.reply_text("❌ Cancelled"))],
    )

    # Bug bounty recon flow
    bb_recon_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(bb_callback, pattern="^bb_")],
        states={
            BB_RECON_TARGET: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, bb_recon_handler)
            ],
            BB_REPORT_TITLE: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, bb_report_handler)
            ]
        },
        fallbacks=[CommandHandler("cancel", lambda u, c: u.message.reply_text("❌ Cancelled"))],
    )

    # Tools recon flow
    # Catatan: whois_handler menangani SEMUA tool (whois/dns/headers/ssl/ports/tech)
    # lewat percabangan internal berdasarkan context.user_data["active_tool"].
    # dns_handler/headers_handler/ssl_handler hanyalah alias yang memanggil whois_handler,
    # jadi cukup didaftarkan satu kali di sini agar tidak ambigu.
    tools_conv = ConversationHandler(
        entry_points=[CallbackQueryHandler(tools_callback, pattern="^tool_")],
        states={
            TOOLS_WAITING_DOMAIN: [
                MessageHandler(filters.TEXT & ~filters.COMMAND, whois_handler),
            ]
        },
        fallbacks=[CommandHandler("cancel", lambda u, c: u.message.reply_text("❌ Cancelled"))],
    )

    # ═══════════════════════════════════════
    # 🛡️ GLOBAL RATE LIMITER (group=-1 → dieksekusi PALING AWAL,
    # sebelum command/callback handler manapun di bawahnya)
    # ═══════════════════════════════════════
    application.add_handler(MessageHandler(filters.ALL, rate_limit_middleware), group=-1)
    application.add_handler(CallbackQueryHandler(rate_limit_middleware), group=-1)

    # ═══════════════════════════════════════
    # 🎯 COMMAND HANDLERS
    # ═══════════════════════════════════════
    application.add_handler(CommandHandler("start", start_handler))
    application.add_handler(CommandHandler("menu", menu_handler))
    application.add_handler(CommandHandler("help", help_handler))
    application.add_handler(CommandHandler("about", about_handler))
    application.add_handler(CommandHandler("status", status_handler))
    application.add_handler(CommandHandler("ai", ai_chat_handler))
    application.add_handler(CommandHandler("ai_clear", ai_clear_handler))
    application.add_handler(CommandHandler("ai_status", ai_status_handler))
    application.add_handler(CommandHandler("buy", payment_handler))
    application.add_handler(CommandHandler("bugbounty", bb_handler))
    application.add_handler(CommandHandler("tools", tools_handler))
    application.add_handler(CommandHandler("admin", admin_handler))

    # Admin commands
    application.add_handler(CommandHandler("broadcast", broadcast_handler))
    application.add_handler(CommandHandler("stats", stats_handler))
    application.add_handler(CommandHandler("ban", ban_handler))
    application.add_handler(CommandHandler("unban", unban_handler))

    # Callback handlers
    application.add_handler(CallbackQueryHandler(menu_callback, pattern="^menu_"))
    application.add_handler(CallbackQueryHandler(verify_payment_callback, pattern="^verify_"))
    application.add_handler(CallbackQueryHandler(admin_callback, pattern="^admin_"))

    # Conversation handlers
    application.add_handler(payment_conv)
    application.add_handler(bb_recon_conv)
    application.add_handler(tools_conv)

    # Error handler
    application.add_error_handler(error_handler)

    # ═══════════════════════════════════════
    # 🚀 START POLLING
    # ═══════════════════════════════════════
    logger.info("🚀 Starting Troxzy Security Bot...")
    application.run_polling(allowed_updates=Update.ALL_TYPES)

if __name__ == "__main__":
    main()
