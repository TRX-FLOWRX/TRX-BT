"""
⚡ TROXZY SECURITY BOT - CONFIGURATION
Badan_Intelijen_Negara System v9.0
Quantum-Neural Hybrid Configuration
"""
import os
from dotenv import load_dotenv

load_dotenv()

# ═══════════════════════════════════════════
# 🔐 CORE BOT CONFIGURATION
# ═══════════════════════════════════════════
BOT_TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
BOT_NAME = "Troxzy Security Bot"
CREATOR = "Troxzy"
VERSION = "v9.0.1-QUANTUM"
RELEASE_DATE = "2026-07-16"

# ═══════════════════════════════════════════
# 🧠 AI API CONFIGURATION (FreeTheAI)
# ═══════════════════════════════════════════
AI_BASE_URL = os.getenv("AI_BASE_URL", "https://api.freetheai.xyz/v1")
AI_API_KEY = os.getenv("AI_API_KEY", "YOUR_API_KEY_HERE")
AI_MODEL = os.getenv("AI_MODEL", "glm/glm-5.2")
AI_MAX_TOKENS = 4096
AI_TEMPERATURE = 0.8

# ═══════════════════════════════════════════
# 💰 PAYMENT CONFIGURATION
# ═══════════════════════════════════════════
QRIS_IMAGE_URL = os.getenv("QRIS_IMAGE_URL", "https://files.catbox.moe/22mzsw.png")
BANNER_IMAGE_URL = os.getenv("BANNER_IMAGE_URL", "https://files.catbox.moe/974uvz.jpg")

# Pricing Plans (IDR)
PLAN_BASIC = 50000      # Basic Recon
PLAN_PRO = 150000       # Advanced Tools
PLAN_ENTERPRISE = 500000 # Full Suite

# Admin IDs (Telegram User IDs)
ADMIN_IDS = list(map(int, os.getenv("ADMIN_IDS", "5727720639").split(",")))

# ═══════════════════════════════════════════
# 🗄️ DATABASE CONFIGURATION
# ═══════════════════════════════════════════
DATABASE_PATH = os.getenv("DATABASE_PATH", "troxzy_bot.db")

# ═══════════════════════════════════════════
# 🛡️ SECURITY & LIMITS
# ═══════════════════════════════════════════
RATE_LIMIT_SECONDS = 3
MAX_REQUESTS_PER_MINUTE = 20
ALLOWED_GROUPS = list(map(int, os.getenv("ALLOWED_GROUPS", "").split(","))) if os.getenv("ALLOWED_GROUPS") else []

# ═══════════════════════════════════════════
# 🌐 EXTERNAL ENDPOINTS
# ═══════════════════════════════════════════
HEADERS_SECURITY = {
    "User-Agent": "TroxzySecurityBot/9.0 (BugBounty; Authorized Scanning Only)",
    "Accept": "application/json",
    "X-Bot-Origin": "Troxzy-BIN-Intel"
}

# ═══════════════════════════════════════════
# 🎨 UI ANIMATION FRAMES
# ═══════════════════════════════════════════
LOADING_FRAMES = ["⚡", "💥", "🔥", "⚡", "💀", "🚀"]
SCAN_FRAMES = ["🔍", "📡", "🛰️", "📡", "🔍"]
AI_THINKING = ["🧠", "⚡", "🔮", "💫", "✨"]

# ═══════════════════════════════════════════
# 📋 BUG BOUNTY PLATFORMS
# ═══════════════════════════════════════════
BB_PLATFORMS = {
    "hackerone": "https://hackerone.com",
    "bugcrowd": "https://bugcrowd.com",
    "intigriti": "https://intigriti.com",
    "yeswehack": "https://yeswehack.com",
    "openbugbounty": "https://openbugbounty.org"
}

# ═══════════════════════════════════════════
# 🔧 TOOL PATHS (Kali Linux - Educational)
# ═══════════════════════════════════════════
# Note: These are wrapper references for authorized testing only
TOOLS = {
    "nmap": "/usr/bin/nmap",
    "subfinder": "/usr/bin/subfinder",
    "amass": "/usr/bin/amass",
    "httpx": "/usr/bin/httpx",
    "naabu": "/usr/bin/naabu",
    "nuclei": "/usr/bin/nuclei",
    "whois": "/usr/bin/whois",
    "dig": "/usr/bin/dig",
    "openssl": "/usr/bin/openssl"
}
